
export enum TaskCategory {
  MENTAL_HEALTH = 'Mental Health',
  DISCIPLINE = 'Discipline',
  HEALTH = 'Health',
  WORK = 'Work',
  STUDY = 'Study',
  HOBBIES = 'Hobbies'
}

export type FocusQuality = 'deep' | 'standard' | 'distracted';

export interface Task {
  id: string;
  title: string;
  category: TaskCategory;
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
  completed: boolean;
  xp: number;
  date: string; // YYYY-MM-DD
  focusQuality?: FocusQuality;
}

export interface RPGStats {
  mentalHealth: number;
  discipline: number;
  health: number;
  work: number;
  study: number;
  hobbies: number;
}

export type ItemType = 'head' | 'torso' | 'legs' | 'feet' | 'accessory' | 'mobile' | 'laptop' | 'bag';

export interface WardrobeItem {
  id: string;
  name: string;
  type: ItemType;
  imageUrl: string;
  scannedAt: string;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

export interface CharacterAppearance {
  skinTone: string;
  hairStyle: string;
  hairColor: string;
  eyeColor: string;
  pose: string;
  bodyType: string;
  facialFeatures: string[];
  background: string;
  basePrompt?: string;
}

export interface PersonalDetails {
  age: number;
  height: string;
  weight: number;
  school: string;
  birthday: string;
}

export enum SkillType {
  COGNITIVE = 'Cognitive',
  PHYSICAL = 'Physical',
  COMMUNICATION = 'Communication',
  TECHNICAL = 'Technical',
  EMOTIONAL = 'Emotional'
}

export enum SkillRank {
  NOVICE = 'Novice',
  APPRENTICE = 'Apprentice',
  SKILLED = 'Skilled',
  ADVANCED = 'Advanced',
  ELITE = 'Elite',
  MASTER = 'Master'
}

export interface SkillProgression {
  type: SkillType;
  xp: number;
  rank: SkillRank;
  lastActivity: string; // ISO date
  subSkills: string[];
}

export interface ReflectionLog {
  id: string;
  date: string;
  content: string;
  analysis: string;
}

export interface Character {
  name: string;
  alias: string;
  bio: string;
  level: number;
  totalXP: number;
  stats: RPGStats;
  avatarUrl: string;
  profilePicUrl: string;
  themeColor: string;
  textColor: string;
  backgroundColor: string;
  wardrobe: WardrobeItem[];
  appearance: CharacterAppearance;
  personalDetails: PersonalDetails;
  learningEfficiency: number; // 1.0 base
  reflections: ReflectionLog[];
  skills: Record<SkillType, SkillProgression>;
  equipped: {
    head?: string;
    torso?: string;
    legs?: string;
    feet?: string;
    accessory?: string;
    mobile?: string;
    laptop?: string;
    bag?: string;
  };
}

export interface Hobby {
  id: string;
  name: string;
  level: number;
  xp: number;
}

export interface GlobalToolsState {
  stopwatch: {
    time: number;
    running: boolean;
  };
  timer: {
    seconds: number;
    running: boolean;
  };
}
