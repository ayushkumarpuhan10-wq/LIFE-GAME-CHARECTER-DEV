
import React, { useState } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Character } from '../types';
import { Activity, Zap, Sparkles } from 'lucide-react';

interface HUDProps {
  character: Character;
}

const HUD: React.FC<HUDProps> = ({ character }) => {
  const [pulseText, setPulseText] = useState<string | null>(null);
  const [isPulsing, setIsPulsing] = useState(false);
  
  const currentLevelXP = character.totalXP % 1000;
  const progress = (currentLevelXP / 1000) * 100;

  const triggerPulse = async () => {
    setIsPulsing(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-lite-latest',
        contents: `Given this user: ${character.alias}, 15yo, 84kg, St. Xaviers. Level ${character.level}. Provide a 1-sentence high-speed cyberpunk motivational pulse.`,
        config: { temperature: 1 }
      });
      setPulseText(response.text || "SYSTEM_SYNC_ERROR");
      setTimeout(() => setPulseText(null), 5000);
    } catch (e) {
      console.error(e);
    } finally {
      setIsPulsing(false);
    }
  };

  return (
    <header className="px-8 py-4 border-b border-blue-500/20 flex flex-col md:flex-row items-center justify-between gap-8 bg-black/90 backdrop-blur-2xl sticky top-0 z-40 cyber-card">
      <div className="flex items-center gap-8">
        <div className="relative group">
          <div className="w-20 h-20 rounded-2xl border border-blue-500/30 flex items-center justify-center overflow-hidden bg-black/40 p-1 group-hover:border-blue-400 transition-all shadow-[0_0_20px_rgba(var(--glow-rgb),0.1)] glitch-container">
            <div className="w-full h-full rounded-xl overflow-hidden relative">
              <img 
                src={character.profilePicUrl} 
                alt="Avatar Headshot" 
                className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-all group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
            </div>
          </div>
          <div className="absolute -bottom-2 -right-2 bg-blue-500 text-black border border-white/20 w-10 h-10 rounded-xl flex items-center justify-center shadow-[0_0_15px_#00f3ff] z-10">
            <span className="font-cyber text-[12px] font-bold">L{character.level}</span>
          </div>
          {/* Decorative Corners */}
          <div className="absolute -top-1 -left-1 w-3 h-3 border-t-2 border-l-2 border-blue-500"></div>
          <div className="absolute -bottom-1 -left-1 w-3 h-3 border-b-2 border-l-2 border-blue-500"></div>
        </div>
        
        <div className="relative">
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[8px] font-mono text-blue-500/50 tracking-[0.3em] uppercase">Identity_Verified</span>
            <div className="h-[1px] w-8 bg-blue-500/20"></div>
          </div>
          <h1 className="font-cyber text-3xl tracking-tighter neon-text leading-none uppercase text-cyber-text">{character.alias}</h1>
          <div className="flex items-center gap-4 mt-3">
            <div className="flex items-center gap-2 bg-green-500/5 px-2 py-1 rounded border border-green-500/20">
              <div className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse shadow-[0_0_8px_#22c55e]"></div>
              <span className="text-[8px] font-cyber text-green-500 tracking-widest">UPLINK_STABLE</span>
            </div>
            <button 
              onClick={triggerPulse}
              disabled={isPulsing}
              className="flex items-center gap-2 text-[8px] font-cyber text-blue-400 hover:text-white transition-all group"
            >
              <Activity size={12} className={isPulsing ? "animate-spin" : "group-hover:scale-125 transition-transform"} />
              <span className="border-b border-blue-500/30 group-hover:border-blue-400">{isPulsing ? "PULSING..." : "GET_TACTICAL_PULSE"}</span>
            </button>
          </div>
          {pulseText && (
            <div className="absolute top-full left-0 mt-4 bg-black/95 text-blue-400 text-[10px] font-cyber p-4 rounded-2xl shadow-[0_0_30px_rgba(var(--glow-rgb),0.2)] animate-in slide-in-from-top-2 fade-in duration-300 z-50 max-w-xs border border-blue-500/40 backdrop-blur-xl">
              <div className="flex items-start gap-3">
                <Zap size={14} className="text-yellow-400 mt-0.5 shrink-0" /> 
                <p className="leading-relaxed tracking-wide">{pulseText.toUpperCase()}</p>
              </div>
              <div className="mt-3 pt-2 border-t border-blue-500/10 flex justify-between items-center">
                <span className="text-[7px] text-slate-600">SOURCE: VELVET_AI</span>
                <div className="flex gap-1">
                  <div className="w-1 h-1 bg-blue-500/50 rounded-full"></div>
                  <div className="w-1 h-1 bg-blue-500/50 rounded-full"></div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div className="flex-1 max-w-xl w-full px-4">
        <div className="flex justify-between items-end mb-3">
          <div className="flex flex-col">
            <span className="font-cyber text-[8px] text-slate-500 tracking-[0.3em] uppercase mb-1">Neural_Synapse_Sync</span>
            <div className="flex items-center gap-2">
              <span className="font-mono text-[10px] text-blue-400">{Math.floor(progress)}%</span>
              <div className="h-1 w-12 bg-blue-500/10 rounded-full overflow-hidden">
                <div className="h-full bg-blue-500" style={{ width: `${progress}%` }}></div>
              </div>
            </div>
          </div>
          <div className="text-right">
            <span className="font-mono text-[10px] text-slate-500">{currentLevelXP} <span className="text-blue-900">/</span> 1000 XP</span>
          </div>
        </div>
        <div className="h-3 w-full bg-blue-950/20 rounded-lg border border-blue-500/20 relative overflow-hidden p-[2px]">
          <div 
            className="h-full bg-gradient-to-r from-blue-600 via-blue-400 to-blue-300 transition-all duration-1000 relative rounded-sm"
            style={{ width: `${progress}%` }}
          >
            <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(255,255,255,0.1)_25%,transparent_25%,transparent_50%,rgba(255,255,255,0.1)_50%,rgba(255,255,255,0.1)_75%,transparent_75%,transparent)] bg-[length:10px_10px] animate-[pulse_2s_infinite]"></div>
            <div className="absolute top-0 right-0 w-1 h-full bg-white/50 shadow-[0_0_10px_white]"></div>
          </div>
        </div>
      </div>

      <div className="flex gap-6">
        <div className="px-6 py-3 border border-blue-500/20 bg-blue-500/5 rounded-2xl flex flex-col items-center min-w-[120px] relative group overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-[1px] bg-blue-500/30"></div>
          <div className="text-[7px] font-cyber text-slate-500 uppercase tracking-[0.4em] mb-2">Total_Experience</div>
          <div className="font-mono text-xl text-cyber-text leading-none group-hover:scale-110 transition-transform">{character.totalXP.toLocaleString()}</div>
        </div>
        <div className="px-6 py-3 border border-purple-500/20 bg-purple-500/5 rounded-2xl flex flex-col items-center min-w-[120px] relative group overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-[1px] bg-purple-500/30"></div>
          <div className="text-[7px] font-cyber text-slate-500 uppercase tracking-[0.4em] mb-2">Network_Rank</div>
          <div className="font-cyber text-sm text-purple-400 leading-none tracking-widest">VANGUARD</div>
        </div>
      </div>
    </header>
  );
};

export default HUD;
