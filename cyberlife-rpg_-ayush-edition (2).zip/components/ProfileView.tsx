
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import { Camera, Shield, Zap, Sparkles, RefreshCw, Layers, User, Edit3, Check, Trash2, Box, Laptop, Smartphone, Briefcase, Shirt, Headphones, Watch, Glasses, Key, AlertTriangle, GraduationCap, Ruler, Weight, Calendar as CalIcon } from 'lucide-react';
import { Character, WardrobeItem, CharacterAppearance, ItemType } from '../types';

interface ProfileViewProps {
  character: Character;
  setCharacter: React.Dispatch<React.SetStateAction<Character>>;
}

const ProfileView: React.FC<ProfileViewProps> = ({ character, setCharacter }) => {
  const [activeSubTab, setActiveSubTab] = useState<'avatar' | 'wardrobe' | 'profile'>('avatar');
  const [isGenerating, setIsGenerating] = useState(false);
  const [isScanning, setIsScanning] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [hasKey, setHasKey] = useState<boolean>(true);
  
  const fileInputRef = useRef<HTMLInputElement>(null);
  const charPhotoInputRef = useRef<HTMLInputElement>(null);
  const avatarContainerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    checkApiKey();
  }, []);

  const checkApiKey = async () => {
    const aistudio = (window as any).aistudio;
    if (aistudio) {
      const selected = await aistudio.hasSelectedApiKey();
      setHasKey(selected);
    }
  };

  const handleSelectKey = async () => {
    const aistudio = (window as any).aistudio;
    if (aistudio) {
      await aistudio.openSelectKey();
      setHasKey(true);
    }
  };

  const convertToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result?.toString().split(',')[1] || '');
      reader.onerror = error => reject(error);
    });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!avatarContainerRef.current) return;
    const rect = avatarContainerRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;
    setMousePos({ x, y });
  };

  const handleRenderAvatar = async (forcedPrompt?: string, base64Context?: string, isCharRecon = false) => {
    if (!hasKey) {
      await handleSelectKey();
    }

    setIsGenerating(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const equippedItems = Object.entries(character.equipped)
        .filter(([_, id]) => id)
        .map(([slot, id]) => {
          const item = character.wardrobe.find(i => i.id === id);
          return item ? `${slot}: ${item.name}` : null;
        })
        .filter(Boolean)
        .join(', ');

      const appearanceDescription = `
        A full-body 3D-style stylized character model (high-fidelity futuristic mesh).
        Body Type: ${character.appearance.bodyType}, 15 year old male, ${character.personalDetails.height}ft height, ${character.personalDetails.weight}kg weight.
        Skin Tone: ${character.appearance.skinTone}, 
        Facial Features: ${character.appearance.facialFeatures.join(', ')},
        Hair Style: ${character.appearance.hairStyle}, 
        Hair Color: ${character.appearance.hairColor}, 
        Eye Color: ${character.appearance.eyeColor}.
        Equipped Gear: ${equippedItems || 'Standard netrunner suit'}.
        Theme: ${character.themeColor} Cyberpunk.
        Pose: ${character.appearance.pose}.
        Background: ${character.appearance.background}.
        ${isCharRecon ? "URGENT: Match the facial structure and body type from the provided reference photo exactly." : ""}
      `;

      let userPrompt = forcedPrompt || `Render this character based on these specs: ${appearanceDescription}`;
      const contents: any[] = [{ text: userPrompt }];

      if (base64Context) {
        contents.push({
          inlineData: {
            data: base64Context,
            mimeType: 'image/jpeg'
          }
        });
        if (!isCharRecon) {
          contents[0].text = `Re-render this 3D character with the new equipment scanned in the photo. Keep existing facial features. Specs: ${appearanceDescription}`;
        }
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-image-preview',
        contents: { parts: contents },
        config: {
          imageConfig: { aspectRatio: "9:16", imageSize: "1K" }
        }
      });

      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData) {
          const newUrl = `data:image/png;base64,${part.inlineData.data}`;
          setCharacter(prev => ({ ...prev, avatarUrl: newUrl }));
          
          const headshotResponse = await ai.models.generateContent({
            model: 'gemini-3-pro-image-preview',
            contents: `Close-up headshot for: ${appearanceDescription}. Frontal view, professional lighting.`,
            config: { imageConfig: { aspectRatio: "1:1" } }
          });
          
          for (const headPart of headshotResponse.candidates[0].content.parts) {
            if (headPart.inlineData) {
              setCharacter(prev => ({ ...prev, profilePicUrl: `data:image/png;base64,${headPart.inlineData.data}` }));
            }
          }
        }
      }
    } catch (err: any) {
      console.error(err);
      const errMsg = err.message || "";
      if (errMsg.includes("PERMISSION_DENIED") || 
          errMsg.includes("Requested entity was not found") ||
          errMsg.includes("does not have permission") ||
          err.status === 403) {
        setHasKey(false);
        await handleSelectKey();
      } else {
        alert("Neural link unstable. System check recommended.");
      }
    } finally {
      setIsGenerating(false);
    }
  };

  const handleAutoRecognizeItem = async (base64: string): Promise<{ name: string, type: ItemType }> => {
    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: [
        {
          inlineData: {
            data: base64,
            mimeType: 'image/jpeg'
          }
        },
        {
          text: "Identify this item for a cyberpunk RPG gear system. Return a JSON object with 'name' (a cool futuristic name for the item) and 'type' (must be one of: 'head', 'torso', 'legs', 'feet', 'accessory', 'mobile', 'laptop', 'bag')."
        }
      ],
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            name: { type: Type.STRING },
            type: { type: Type.STRING, enum: ['head', 'torso', 'legs', 'feet', 'accessory', 'mobile', 'laptop', 'bag'] }
          },
          required: ['name', 'type']
        }
      }
    });

    try {
      return JSON.parse(response.text || '{"name":"Unknown Asset","type":"accessory"}');
    } catch (e) {
      return { name: "Neural Fragment", type: "accessory" };
    }
  };

  const handleScanItemAuto = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsScanning(true);
    try {
      const base64 = await convertToBase64(file);
      const recognized = await handleAutoRecognizeItem(base64);
      
      const newItem: WardrobeItem = {
        id: Math.random().toString(36).substr(2, 9),
        name: recognized.name,
        type: recognized.type,
        imageUrl: URL.createObjectURL(file),
        scannedAt: new Date().toISOString(),
        rarity: 'rare'
      };
      
      setCharacter(prev => ({ 
        ...prev, 
        wardrobe: [newItem, ...prev.wardrobe],
        equipped: { ...prev.equipped, [newItem.type]: newItem.id }
      }));
      
      await handleRenderAvatar(`Update avatar wearing the new gear: ${recognized.name}`, base64);
    } catch (err: any) {
      console.error(err);
      if (err.message?.includes("PERMISSION_DENIED")) {
        setHasKey(false);
        await handleSelectKey();
      } else {
        alert("Neural scan failed. Connection unstable.");
      }
    } finally {
      setIsScanning(false);
    }
  };

  const handleCharPhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setIsGenerating(true);
    try {
      const base64 = await convertToBase64(file);
      await handleRenderAvatar("Create a 3D avatar that looks exactly like the person in this photo, but in a cyberpunk style.", base64, true);
    } catch (err) { console.error(err); }
    finally { setIsGenerating(false); }
  };

  const toggleEquip = (item: WardrobeItem) => {
    const isEquipped = character.equipped[item.type] === item.id;
    setCharacter(prev => ({
      ...prev,
      equipped: {
        ...prev.equipped,
        [item.type]: isEquipped ? undefined : item.id
      }
    }));
  };

  const deleteItem = (id: string) => {
    setCharacter(prev => ({
      ...prev,
      wardrobe: prev.wardrobe.filter(item => item.id !== id),
      equipped: Object.fromEntries(
        Object.entries(prev.equipped).map(([k, v]) => [k, v === id ? undefined : v])
      ) as any
    }));
  };

  const updateItemName = (id: string, newName: string) => {
    setCharacter(prev => ({
      ...prev,
      wardrobe: prev.wardrobe.map(item => item.id === id ? { ...item, name: newName } : item)
    }));
  };

  const getIcon = (type: ItemType) => {
    switch(type) {
      case 'torso': return <Shirt size={14} />;
      case 'mobile': return <Smartphone size={14} />;
      case 'laptop': return <Laptop size={14} />;
      case 'bag': return <Briefcase size={14} />;
      case 'head': return <Glasses size={14} />;
      case 'accessory': return <Watch size={14} />;
      default: return <Box size={14} />;
    }
  };

  return (
    <div className="max-w-7xl mx-auto h-[calc(100vh-140px)] flex flex-col md:flex-row gap-8">
      
      <div 
        ref={avatarContainerRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={() => setMousePos({ x: 0, y: 0 })}
        className="flex-1 relative group avatar-container h-full min-h-[500px]"
      >
        <div 
          className="avatar-3d h-full w-full rounded-[40px] border-2 neon-border overflow-hidden bg-gradient-to-b from-blue-900/10 via-black to-black relative shadow-2xl"
          style={{ transform: `rotateY(${mousePos.x * 12}deg) rotateX(${mousePos.y * -12}deg)` }}
        >
          <img 
            src={character.avatarUrl} 
            alt="Character" 
            className="w-full h-full object-cover select-none pointer-events-none transition-opacity duration-500" 
            style={{ opacity: (isGenerating || isScanning) ? 0.3 : 1 }}
          />

          {(isGenerating || isScanning) && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/40 backdrop-blur-sm z-20">
              <RefreshCw className="text-blue-400 animate-spin mb-4" size={48} />
              <span className="font-cyber text-[10px] text-blue-400 tracking-[0.3em] animate-pulse">
                {isScanning ? "AUTO_RECOGNIZING_ASSET..." : "UPDATING_CORE_MESH"}
              </span>
            </div>
          )}

          <div className="absolute top-10 right-10 flex flex-col gap-2">
            {Object.entries(character.equipped).map(([slot, id]) => {
              if (!id) return null;
              const item = character.wardrobe.find(i => i.id === id);
              return item && (
                <div key={slot} className="bg-black/60 border border-blue-500/30 px-3 py-1 rounded-full flex items-center gap-2 backdrop-blur-md">
                   {getIcon(item.type)}
                   <span className="text-[8px] font-cyber text-blue-200">{item.name}</span>
                </div>
              );
            })}
          </div>

          {!hasKey && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/80 backdrop-blur-md z-40 p-12 text-center">
              <AlertTriangle className="text-yellow-500 mb-4" size={48} />
              <h3 className="font-cyber text-xl text-white mb-2 uppercase">Neural_Link_Restricted</h3>
              <p className="text-xs text-slate-400 mb-6 max-w-xs">A paid API key is required to render high-fidelity 3D avatars. Connect your billing-enabled GCP project.</p>
              <button 
                onClick={handleSelectKey}
                className="bg-blue-500 hover:bg-blue-400 text-black font-cyber text-xs px-8 py-4 rounded-xl shadow-lg transition-all"
              >
                CONNECT_NEURAL_LINK
              </button>
              <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="mt-4 text-[10px] font-cyber text-blue-400 underline opacity-50 hover:opacity-100">VIEW_BILLING_DOCS</a>
            </div>
          )}
        </div>

        <div className="absolute bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-3 z-30">
          <button 
            onClick={() => charPhotoInputRef.current?.click()}
            disabled={isGenerating || isScanning || !hasKey}
            className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white font-cyber text-[10px] rounded-full shadow-lg hover:bg-indigo-500 transition-all border border-indigo-400/50 disabled:opacity-50 group/ref"
          >
            <Camera size={14} className="group-hover/ref:rotate-12 transition-transform" /> 
            <div className="flex flex-col items-start leading-none">
              <span>UPLOAD_REFERENCE</span>
              <span className="text-[6px] opacity-50">FOR_ACCURATE_RECON</span>
            </div>
          </button>
          <input type="file" hidden ref={charPhotoInputRef} onChange={handleCharPhotoUpload} accept="image/*" />
          
          <button 
            onClick={() => handleRenderAvatar()}
            disabled={isGenerating || isScanning || !hasKey}
            className="flex items-center gap-3 px-8 py-4 bg-white text-black font-cyber text-xs rounded-full shadow-[0_0_20px_rgba(255,255,255,0.4)] hover:scale-105 active:scale-95 transition-all disabled:opacity-50"
          >
            <Sparkles size={18} /> SYNC_NEURAL_MESH
          </button>
        </div>
      </div>

      <div className="w-full md:w-[480px] flex flex-col gap-6">
        
        <div className="flex bg-blue-900/10 p-1 rounded-2xl border border-blue-900/20">
          {[
            { id: 'avatar', icon: User, label: 'Appearance' },
            { id: 'wardrobe', icon: Box, label: 'Gears' },
            { id: 'profile', icon: Edit3, label: 'Identity' }
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-cyber text-[10px] transition-all ${
                activeSubTab === tab.id ? 'bg-blue-500 text-black shadow-lg shadow-blue-500/20' : 'text-slate-500 hover:text-blue-400'
              }`}
            >
              <tab.icon size={14} /> {tab.label.toUpperCase()}
            </button>
          ))}
        </div>

        <div className="flex-1 bg-black/40 border border-blue-900/20 rounded-[32px] p-6 overflow-y-auto custom-scrollbar">
          
          {activeSubTab === 'avatar' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-4">
               <section className="bg-blue-500/5 border border-blue-500/20 p-4 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Key size={16} className={hasKey ? 'text-green-500' : 'text-red-500'} />
                  <div>
                    <h4 className="text-[10px] font-cyber text-white uppercase">Neural_Link_Status</h4>
                    <p className="text-[8px] text-slate-500">{hasKey ? 'ACTIVE_AND_SYNCHRONIZED' : 'CONNECTION_REQUIRED'}</p>
                  </div>
                </div>
                <button onClick={handleSelectKey} className="p-2 hover:bg-blue-500/20 rounded-lg transition-all">
                  <RefreshCw size={14} className="text-blue-400" />
                </button>
              </section>

              <section>
                <h4 className="text-[10px] font-cyber text-slate-500 mb-4 tracking-widest uppercase">Biometric_Profile</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-black/60 border border-blue-900/20 p-3 rounded-xl flex items-center gap-3">
                    <Ruler size={16} className="text-blue-400" />
                    <div>
                      <div className="text-[8px] font-cyber text-slate-500">HEIGHT</div>
                      <input 
                        value={character.personalDetails.height}
                        onChange={e => setCharacter(p => ({ ...p, personalDetails: { ...p.personalDetails, height: e.target.value } }))}
                        className="bg-transparent border-none text-[10px] font-cyber text-blue-200 w-full outline-none"
                      />
                    </div>
                  </div>
                  <div className="bg-black/60 border border-blue-900/20 p-3 rounded-xl flex items-center gap-3">
                    <Weight size={16} className="text-blue-400" />
                    <div>
                      <div className="text-[8px] font-cyber text-slate-500">WEIGHT_KG</div>
                      <input 
                        type="number"
                        value={character.personalDetails.weight}
                        onChange={e => setCharacter(p => ({ ...p, personalDetails: { ...p.personalDetails, weight: parseInt(e.target.value) || 0 } }))}
                        className="bg-transparent border-none text-[10px] font-cyber text-blue-200 w-full outline-none"
                      />
                    </div>
                  </div>
                  <div className="bg-black/60 border border-blue-900/20 p-3 rounded-xl flex items-center gap-3">
                    <GraduationCap size={16} className="text-blue-400" />
                    <div>
                      <div className="text-[8px] font-cyber text-slate-500">SCHOOL</div>
                      <input 
                        value={character.personalDetails.school}
                        onChange={e => setCharacter(p => ({ ...p, personalDetails: { ...p.personalDetails, school: e.target.value } }))}
                        className="bg-transparent border-none text-[10px] font-cyber text-blue-200 w-full outline-none"
                      />
                    </div>
                  </div>
                  <div className="bg-black/60 border border-blue-900/20 p-3 rounded-xl flex items-center gap-3">
                    <CalIcon size={16} className="text-blue-400" />
                    <div>
                      <div className="text-[8px] font-cyber text-slate-500">BIRTHDAY</div>
                      <input 
                        type="date"
                        value={character.personalDetails.birthday}
                        onChange={e => setCharacter(p => ({ ...p, personalDetails: { ...p.personalDetails, birthday: e.target.value } }))}
                        className="bg-transparent border-none text-[10px] font-cyber text-blue-200 w-full outline-none"
                      />
                    </div>
                  </div>
                </div>
              </section>

              <section>
                <h4 className="text-[10px] font-cyber text-slate-500 mb-4 tracking-widest uppercase">Body_Morphology</h4>
                <div className="grid grid-cols-3 gap-2">
                  {['Athletic', 'Slim', 'Muscular', 'Cybernetic', 'Heavy', 'Agile'].map(type => (
                    <button 
                      key={type}
                      onClick={() => setCharacter(p => ({ ...p, appearance: { ...p.appearance, bodyType: type } }))}
                      className={`p-2 rounded-xl text-[9px] font-cyber border transition-all ${
                        character.appearance.bodyType === type ? 'border-blue-500 bg-blue-500/10 text-blue-400' : 'border-slate-800 text-slate-500 hover:border-slate-600'
                      }`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
              </section>

              <section>
                <h4 className="text-[10px] font-cyber text-slate-500 mb-4 tracking-widest uppercase">Facial_Augmentations</h4>
                <div className="flex flex-wrap gap-2">
                  {['Neon-Tattoo', 'Cyber-Eye', 'Scar', 'Chrome-Jaw', 'Data-Port', 'Neural-Link', 'Subdermal-LED', 'Ocular-Overlay', 'Synthetic-Skin', 'Tech-Freckles'].map(feature => (
                    <button 
                      key={feature}
                      onClick={() => {
                        const exists = character.appearance.facialFeatures.includes(feature);
                        setCharacter(p => ({ 
                          ...p, 
                          appearance: { 
                            ...p.appearance, 
                            facialFeatures: exists 
                              ? p.appearance.facialFeatures.filter(f => f !== feature)
                              : [...p.appearance.facialFeatures, feature]
                          } 
                        }));
                      }}
                      className={`px-3 py-1.5 rounded-full text-[8px] font-cyber border transition-all ${
                        character.appearance.facialFeatures.includes(feature) ? 'border-purple-500 bg-purple-500/10 text-purple-400' : 'border-slate-800 text-slate-500 hover:border-slate-600'
                      }`}
                    >
                      {feature}
                    </button>
                  ))}
                </div>
              </section>

              <section>
                <h4 className="text-[10px] font-cyber text-slate-500 mb-4 tracking-widest uppercase">Environment_Matrix</h4>
                <div className="grid grid-cols-2 gap-2">
                  {['Holographic-Pedestal', 'Neon-City-Rain', 'Underground-Lab', 'Data-Stream-Void', 'Cyber-Apartment', 'Orbital-Station', 'Wasteland-Outpost', 'Corporate-Highrise', 'Virtual-Reality-Grid', 'Deep-Net-Node'].map(bg => (
                    <button 
                      key={bg}
                      onClick={() => setCharacter(p => ({ ...p, appearance: { ...p.appearance, background: bg } }))}
                      className={`p-2 rounded-xl text-[9px] font-cyber border transition-all ${
                        character.appearance.background === bg ? 'border-emerald-500 bg-emerald-500/10 text-emerald-400' : 'border-slate-800 text-slate-500 hover:border-slate-600'
                      }`}
                    >
                      {bg.replace(/-/g, ' ')}
                    </button>
                  ))}
                </div>
              </section>

              <section>
                <h4 className="text-[10px] font-cyber text-slate-500 mb-4 tracking-widest uppercase">Pose_Protocol</h4>
                <div className="grid grid-cols-3 gap-2">
                  {['Dynamic', 'Heroic', 'Stealthy', 'Relaxed', 'Combat-Ready', 'Floating'].map(pose => (
                    <button 
                      key={pose}
                      onClick={() => setCharacter(p => ({ ...p, appearance: { ...p.appearance, pose: pose } }))}
                      className={`p-2 rounded-xl text-[9px] font-cyber border transition-all ${
                        character.appearance.pose === pose ? 'border-orange-500 bg-orange-500/10 text-orange-400' : 'border-slate-800 text-slate-500 hover:border-slate-600'
                      }`}
                    >
                      {pose}
                    </button>
                  ))}
                </div>
              </section>

              <section>
                <h4 className="text-[10px] font-cyber text-slate-500 mb-4 tracking-widest uppercase">Dermal_Synthesis</h4>
                <div className="flex flex-wrap gap-3">
                  {['#f5d0c5', '#d2b48c', '#8d5524', '#c68642', '#e0ac69', '#f1c27d', '#ffdbac', '#3c2e28'].map(tone => (
                    <button 
                      key={tone}
                      onClick={() => setCharacter(p => ({ ...p, appearance: { ...p.appearance, skinTone: tone } }))}
                      className={`w-8 h-8 rounded-full border-2 transition-all ${character.appearance.skinTone === tone ? 'border-white scale-110 shadow-lg' : 'border-transparent opacity-60 hover:opacity-100'}`}
                      style={{ backgroundColor: tone }}
                    />
                  ))}
                </div>
              </section>

              <section>
                <h4 className="text-[10px] font-cyber text-slate-500 mb-4 tracking-widest">NEURAL_HAIR_PROTOCOLS</h4>
                <div className="grid grid-cols-3 gap-2">
                  {['Buzzcut', 'Samurai-Knot', 'Cyber-Undercut', 'Spiky-Neon', 'Long-Net', 'Fade'].map(style => (
                    <button 
                      key={style}
                      onClick={() => setCharacter(p => ({ ...p, appearance: { ...p.appearance, hairStyle: style } }))}
                      className={`p-2 rounded-xl text-[9px] font-cyber border transition-all ${
                        character.appearance.hairStyle === style ? 'border-blue-500 bg-blue-500/10 text-blue-400' : 'border-slate-800 text-slate-500 hover:border-slate-600'
                      }`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </section>

              <section>
                <h4 className="text-[10px] font-cyber text-slate-500 mb-4 tracking-widest">PIGMENT_SYNTHESIS</h4>
                <div className="flex flex-wrap gap-3">
                  {['#00f3ff', '#bc13fe', '#00ff9d', '#ff0055', '#ffffff', '#ffd700', '#222222'].map(color => (
                    <button 
                      key={color}
                      onClick={() => setCharacter(p => ({ ...p, appearance: { ...p.appearance, hairColor: color } }))}
                      className={`w-10 h-10 rounded-full border-2 transition-all ${character.appearance.hairColor === color ? 'border-white scale-110 shadow-lg' : 'border-transparent opacity-60 hover:opacity-100'}`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </section>
            </div>
          )}

          {activeSubTab === 'wardrobe' && (
            <div className="space-y-6 animate-in fade-in slide-in-from-right-4">
              <div className="bg-purple-900/10 p-5 rounded-3xl border border-purple-500/20">
                <div className="flex items-center gap-3 mb-4">
                  <div className="p-3 bg-purple-500/20 rounded-2xl">
                    <Sparkles className="text-purple-400" size={24} />
                  </div>
                  <div>
                    <h4 className="font-cyber text-xs text-white">AI_AUTO_SCANNER</h4>
                    <p className="text-[8px] text-slate-500">UPLOAD A PIC TO RECOGNIZE GEAR</p>
                  </div>
                </div>
                
                <button 
                  onClick={() => fileInputRef.current?.click()}
                  disabled={isScanning || !hasKey}
                  className="w-full bg-purple-600 hover:bg-purple-500 disabled:opacity-50 text-white text-[10px] font-cyber py-4 rounded-2xl transition-all shadow-xl shadow-purple-900/20 flex items-center justify-center gap-2"
                >
                  {isScanning ? <RefreshCw size={16} className="animate-spin" /> : <Camera size={16} />}
                  {isScanning ? "RECOGNIZING..." : "SCAN_REAL_GEAR"}
                </button>
                <input type="file" hidden ref={fileInputRef} onChange={handleScanItemAuto} accept="image/*" />
              </div>

              <div className="space-y-4">
                <h4 className="text-[10px] font-cyber text-slate-500 tracking-widest uppercase">Inventory_Matrix</h4>
                <div className="grid grid-cols-2 gap-4">
                  {character.wardrobe.map(item => (
                    <div 
                      key={item.id} 
                      className={`relative group rounded-3xl border p-2 overflow-hidden bg-black/60 transition-all ${
                        character.equipped[item.type] === item.id ? 'border-blue-500 ring-1 ring-blue-500/30' : 'border-blue-900/20 hover:border-blue-700'
                      }`}
                    >
                      <div className="aspect-square rounded-2xl overflow-hidden relative mb-2">
                        <img src={item.imageUrl} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                        <div className="absolute top-2 right-2 p-1 bg-black/60 backdrop-blur-md rounded-lg">
                           {getIcon(item.type)}
                        </div>
                        <button 
                          onClick={() => toggleEquip(item)}
                          className={`absolute inset-0 flex items-center justify-center transition-all ${
                            character.equipped[item.type] === item.id ? 'bg-blue-500/10' : 'opacity-0 group-hover:opacity-100 bg-black/40'
                          }`}
                        >
                          {character.equipped[item.type] === item.id ? <Check size={24} className="text-blue-400" /> : <Zap size={24} className="text-white" />}
                        </button>
                      </div>
                      
                      <div className="px-2 pb-2">
                        {editingItemId === item.id ? (
                          <input 
                            autoFocus
                            value={item.name}
                            onChange={(e) => updateItemName(item.id, e.target.value)}
                            onBlur={() => setEditingItemId(null)}
                            onKeyDown={(e) => e.key === 'Enter' && setEditingItemId(null)}
                            className="w-full bg-blue-900/20 border-b border-blue-500 text-[10px] font-cyber text-blue-200 outline-none p-1"
                          />
                        ) : (
                          <div className="flex justify-between items-center group/name">
                            <span className="text-[10px] font-cyber text-blue-200 truncate">{item.name}</span>
                            <div className="flex gap-1 opacity-0 group-hover/name:opacity-100 transition-opacity">
                              <button onClick={() => setEditingItemId(item.id)} className="text-slate-500 hover:text-white"><Edit3 size={10} /></button>
                              <button onClick={() => deleteItem(item.id)} className="text-red-900/50 hover:text-red-500"><Trash2 size={10} /></button>
                            </div>
                          </div>
                        )}
                        <div className="text-[8px] font-cyber text-slate-600 mt-1 uppercase">{item.type}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeSubTab === 'profile' && (
            <div className="space-y-6">
               <div className="space-y-2">
                <label className="text-[10px] font-cyber text-slate-500 uppercase">Legal_Identity</label>
                <input 
                  value={character.name}
                  onChange={e => setCharacter(p => ({ ...p, name: e.target.value }))}
                  className="w-full bg-black/60 border border-blue-900/30 p-4 rounded-2xl font-cyber text-sm text-blue-400 focus:neon-border outline-none transition-all"
                />
              </div>
               <div className="space-y-2">
                <label className="text-[10px] font-cyber text-slate-500 uppercase">Identity_Alias</label>
                <input 
                  value={character.alias}
                  onChange={e => setCharacter(p => ({ ...p, alias: e.target.value }))}
                  className="w-full bg-black/60 border border-blue-900/30 p-4 rounded-2xl font-cyber text-sm text-blue-400 focus:neon-border outline-none transition-all"
                />
              </div>
              <div className="space-y-4">
                <label className="text-[10px] font-cyber text-slate-500 uppercase">Core_Visual_Theme (100+ Matrix)</label>
                <div className="grid grid-cols-10 gap-1 bg-black/40 p-2 rounded-2xl border border-white/5">
                  {Array.from({ length: 100 }).map((_, i) => {
                    const hue = (i * 3.6);
                    const color = `hsl(${hue}, 100%, 50%)`;
                    // Convert HSL to HEX for storage consistency
                    const h = hue / 360;
                    const s = 1;
                    const l = 0.5;
                    let r, g, b;
                    
                    const q = l < 0.5 ? l * (1 + s) : l + s - l * s;
                    const p = 2 * l - q;
                    const hue2rgb = (t: number) => {
                      if (t < 0) t += 1;
                      if (t > 1) t -= 1;
                      if (t < 1/6) return p + (q - p) * 6 * t;
                      if (t < 1/2) return q;
                      if (t < 2/3) return p + (q - p) * (2/3 - t) * 6;
                      return p;
                    };
                    r = hue2rgb(h + 1/3);
                    g = hue2rgb(h);
                    b = hue2rgb(h - 1/3);
                    const toHex = (x: number) => {
                      const hex = Math.round(x * 255).toString(16);
                      return hex.length === 1 ? '0' + hex : hex;
                    };
                    const hexColor = `#${toHex(r)}${toHex(g)}${toHex(b)}`;
                    
                    return (
                      <button 
                        key={i}
                        onClick={() => setCharacter(p => ({ ...p, themeColor: hexColor }))}
                        className={`aspect-square rounded-sm transition-all hover:scale-125 z-10 ${character.themeColor === hexColor ? 'ring-2 ring-white scale-110' : 'opacity-60 hover:opacity-100'}`}
                        style={{ backgroundColor: hexColor }}
                        title={hexColor}
                      />
                    );
                  })}
                </div>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
                  <div className="flex items-center gap-4">
                    <div 
                      className="w-12 h-12 rounded-xl border-2 border-white/20 shadow-lg"
                      style={{ backgroundColor: character.themeColor, boxShadow: `0 0 20px ${character.themeColor}` }}
                    />
                    <div>
                      <div className="text-[10px] font-cyber text-white">THEME_HEX</div>
                      <div className="text-xs font-mono text-blue-400 uppercase">{character.themeColor}</div>
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-cyber text-slate-500 uppercase">Custom_Theme</label>
                    <div className="flex items-center gap-2">
                      <input 
                        type="color" 
                        value={character.themeColor}
                        onChange={e => setCharacter(p => ({ ...p, themeColor: e.target.value }))}
                        className="w-8 h-8 bg-transparent border-none cursor-pointer"
                      />
                      <input 
                        type="text"
                        value={character.themeColor}
                        onChange={e => setCharacter(p => ({ ...p, themeColor: e.target.value }))}
                        className="bg-black/40 border border-white/10 rounded px-2 py-1 text-[10px] font-mono text-blue-400 w-20 outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-cyber text-slate-500 uppercase">Text_Color</label>
                    <div className="flex items-center gap-2">
                      <input 
                        type="color" 
                        value={character.textColor}
                        onChange={e => setCharacter(p => ({ ...p, textColor: e.target.value }))}
                        className="w-8 h-8 bg-transparent border-none cursor-pointer"
                      />
                      <input 
                        type="text"
                        value={character.textColor}
                        onChange={e => setCharacter(p => ({ ...p, textColor: e.target.value }))}
                        className="bg-black/40 border border-white/10 rounded px-2 py-1 text-[10px] font-mono text-blue-400 w-20 outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>
                  <div className="space-y-1">
                    <label className="text-[8px] font-cyber text-slate-500 uppercase">BG_Color</label>
                    <div className="flex items-center gap-2">
                      <input 
                        type="color" 
                        value={character.backgroundColor}
                        onChange={e => setCharacter(p => ({ ...p, backgroundColor: e.target.value }))}
                        className="w-8 h-8 bg-transparent border-none cursor-pointer"
                      />
                      <input 
                        type="text"
                        value={character.backgroundColor}
                        onChange={e => setCharacter(p => ({ ...p, backgroundColor: e.target.value }))}
                        className="bg-black/40 border border-white/10 rounded px-2 py-1 text-[10px] font-mono text-blue-400 w-20 outline-none focus:border-blue-500"
                      />
                    </div>
                  </div>
                  <div className="flex items-end pb-1">
                    <button 
                      onClick={() => setCharacter(p => ({ ...p, themeColor: '#00f3ff', textColor: '#ffffff', backgroundColor: '#000000' }))}
                      className="px-3 py-1 bg-red-500/10 border border-red-500/30 text-red-500 text-[8px] font-cyber rounded hover:bg-red-500 hover:text-white transition-all uppercase"
                    >
                      Reset_Defaults
                    </button>
                  </div>
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-cyber text-slate-500 uppercase">Neural_Signature (Bio)</label>
                <textarea 
                  value={character.bio}
                  onChange={e => setCharacter(p => ({ ...p, bio: e.target.value }))}
                  className="w-full bg-black/60 border border-blue-900/30 p-4 rounded-2xl font-cyber text-xs text-blue-200 h-32 outline-none resize-none"
                />
              </div>
            </div>
          )}
        </div>

        <div className="p-4 bg-white/5 border border-white/10 rounded-[28px] flex items-center gap-4">
          <div className="w-14 h-14 rounded-full border border-blue-500/50 overflow-hidden bg-black shadow-[0_0_10px_rgba(0,243,255,0.2)]">
            <img src={character.profilePicUrl} className="w-full h-full object-cover" />
          </div>
          <div className="flex-1">
            <div className="font-cyber text-[10px] text-blue-400">ACTIVE_IDENTITY</div>
            <div className="text-white text-sm font-semibold">{character.alias}</div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileView;
