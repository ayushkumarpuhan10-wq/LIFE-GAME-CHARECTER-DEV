
import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, SkipForward, SkipBack, Volume2, Music, Search, Activity, Globe } from 'lucide-react';
import { GoogleGenAI } from '@google/genai';

interface Track {
  id: string;
  title: string;
  artist: string;
  url: string;
  type: 'ambient' | 'lofi' | 'synthwave';
}

const AmbiancePlayer: React.FC = () => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTrackIndex, setCurrentTrackIndex] = useState(0);
  const [volume, setVolume] = useState(0.5);
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const [tracks, setTracks] = useState<Track[]>([
    { id: '1', title: 'NEON_RAIN', artist: 'CYBER_CORE', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3', type: 'ambient' },
    { id: '2', title: 'SYNTH_WAVE_01', artist: 'RETRO_TECH', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3', type: 'synthwave' },
    { id: '3', title: 'LOFI_DREAMS', artist: 'CHILL_BOT', url: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3', type: 'lofi' },
  ]);

  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = volume;
    }
  }, [volume]);

  const togglePlay = () => {
    if (audioRef.current) {
      if (isPlaying) {
        audioRef.current.pause();
      } else {
        audioRef.current.play().catch(e => console.error("Playback failed:", e));
      }
      setIsPlaying(!isPlaying);
    }
  };

  const skipTrack = (direction: 'next' | 'prev') => {
    let nextIndex = currentTrackIndex;
    if (direction === 'next') {
      nextIndex = (currentTrackIndex + 1) % tracks.length;
    } else {
      nextIndex = (currentTrackIndex - 1 + tracks.length) % tracks.length;
    }
    setCurrentTrackIndex(nextIndex);
    setIsPlaying(false);
    // Auto play next track
    setTimeout(() => {
      if (audioRef.current) {
        audioRef.current.play().catch(e => console.error("Playback failed:", e));
        setIsPlaying(true);
      }
    }, 100);
  };

  const handleSearch = async () => {
    if (!query.trim()) return;
    setIsSearching(true);
    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) return;
      const ai = new GoogleGenAI({ apiKey });
      
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Recommend a cyberpunk ambient track or soundscape for: ${query}. Return JSON: { "title": "Track Name", "artist": "Artist", "description": "Brief description" }`,
        config: { responseMimeType: "application/json" }
      });

      const recommendation = JSON.parse(response.text);
      // Since we can't actually fetch real MP3s from Google Search easily without a backend proxy or specific API,
      // we'll "simulate" adding a track based on the recommendation.
      const newTrack: Track = {
        id: Math.random().toString(36).substr(2, 9),
        title: recommendation.title.toUpperCase(),
        artist: recommendation.artist.toUpperCase(),
        url: tracks[0].url, // Use a placeholder for now
        type: 'ambient'
      };
      setTracks(prev => [newTrack, ...prev]);
      setCurrentTrackIndex(0);
      setIsPlaying(false);
    } catch (err) {
      console.error("Ambiance search error:", err);
    } finally {
      setIsSearching(false);
    }
  };

  const currentTrack = tracks[currentTrackIndex];

  return (
    <div className="cyber-card p-6 rounded-3xl border border-blue-500/20 bg-black/60 backdrop-blur-xl relative overflow-hidden group">
      <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-20 transition-opacity">
        <Music size={80} />
      </div>
      
      <div className="flex justify-between items-start mb-6 relative z-10">
        <div>
          <h3 className="text-[10px] font-cyber text-blue-400 flex items-center gap-2 tracking-widest">
            <Activity size={12} /> NEURAL_AMBIANCE_PLAYER
          </h3>
          <p className="text-[8px] font-mono text-slate-500 mt-1 uppercase">Audio_Link: {isPlaying ? 'Streaming' : 'Standby'}</p>
        </div>
        <div className="flex gap-2 items-center">
          <div className="flex items-center gap-1 px-2 py-0.5 bg-blue-500/10 border border-blue-500/20 rounded text-[7px] font-cyber text-blue-400">
            <Globe size={8} /> GOOGLE_SYNC_ACTIVE
          </div>
          <input 
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleSearch()}
            placeholder="SEARCH_SOUNDSCAPES..."
            className="bg-black/40 border border-white/10 rounded-lg px-3 py-1 text-[10px] font-cyber text-blue-200 outline-none focus:border-blue-500 transition-all w-40"
          />
          <button 
            onClick={handleSearch}
            disabled={isSearching}
            className="p-1.5 bg-blue-500/20 border border-blue-500/30 rounded-lg text-blue-400 hover:bg-blue-500 hover:text-black transition-all disabled:opacity-50"
          >
            {isSearching ? <Activity size={12} className="animate-spin" /> : <Search size={12} />}
          </button>
        </div>
      </div>

      <div className="flex flex-col items-center gap-6 py-4">
        <div className="relative">
          <div className={`w-32 h-32 rounded-full border-2 ${isPlaying ? 'border-blue-500 animate-[spin_10s_linear_infinite]' : 'border-blue-500/20'} flex items-center justify-center relative overflow-hidden`}>
            <div className="absolute inset-0 bg-[radial-gradient(circle,rgba(0,243,255,0.1)_0%,transparent_70%)]"></div>
            <Music size={40} className={isPlaying ? 'text-blue-400 animate-pulse' : 'text-blue-500/20'} />
          </div>
          {isPlaying && (
            <div className="absolute -inset-2 border border-blue-500/30 rounded-full animate-ping opacity-20"></div>
          )}
        </div>

        <div className="text-center">
          <div className="text-xl font-cyber text-white mb-1 tracking-tighter">{currentTrack.title}</div>
          <div className="text-[10px] font-mono text-blue-500/70 uppercase tracking-widest">{currentTrack.artist}</div>
        </div>

        <div className="flex items-center gap-8">
          <button onClick={() => skipTrack('prev')} className="text-slate-500 hover:text-blue-400 transition-colors">
            <SkipBack size={24} />
          </button>
          <button 
            onClick={togglePlay}
            className="w-16 h-16 bg-blue-500 text-black rounded-full flex items-center justify-center hover:scale-110 active:scale-95 transition-all shadow-[0_0_20px_rgba(0,243,255,0.4)]"
          >
            {isPlaying ? <Pause size={32} /> : <Play size={32} className="ml-1" />}
          </button>
          <button onClick={() => skipTrack('next')} className="text-slate-500 hover:text-blue-400 transition-colors">
            <SkipForward size={24} />
          </button>
        </div>

        <div className="w-full flex items-center gap-4 px-4">
          <Volume2 size={16} className="text-slate-500" />
          <input 
            type="range"
            min="0"
            max="1"
            step="0.01"
            value={volume}
            onChange={(e) => setVolume(parseFloat(e.target.value))}
            className="flex-1 h-1 bg-blue-950 rounded-full appearance-none cursor-pointer accent-blue-500"
          />
        </div>
      </div>

      <audio 
        ref={audioRef}
        src={currentTrack.url}
        onEnded={() => skipTrack('next')}
      />

      <div className="mt-6 flex justify-between items-center pt-4 border-t border-white/5">
        <div className="text-[8px] font-cyber text-blue-500/50 uppercase">Neural_Audio_Link: v1.0.4</div>
        <div className="flex gap-1">
          {tracks.map((_, i) => (
            <div key={i} className={`w-1.5 h-1.5 rounded-full ${i === currentTrackIndex ? 'bg-blue-500 shadow-[0_0_5px_#00f3ff]' : 'bg-white/10'}`}></div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default AmbiancePlayer;
