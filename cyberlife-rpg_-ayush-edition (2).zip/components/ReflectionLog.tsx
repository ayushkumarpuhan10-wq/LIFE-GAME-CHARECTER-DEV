
import React, { useState } from 'react';
import { Character, ReflectionLog } from '../types';
import { Brain, MessageSquare, Save, History, Sparkles } from 'lucide-react';

interface ReflectionLogProps {
  character: Character;
  onAddReflection: (content: string, analysis: string) => void;
}

const ReflectionLogView: React.FC<ReflectionLogProps> = ({ character, onAddReflection }) => {
  const [content, setContent] = useState('');
  const [analysis, setAnalysis] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!content || !analysis) return;
    setIsSubmitting(true);
    setTimeout(() => {
      onAddReflection(content, analysis);
      setContent('');
      setAnalysis('');
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center border-b border-emerald-900/30 pb-4">
        <div>
          <h2 className="font-cyber text-2xl text-emerald-400 neon-text-emerald">NEURAL_REFLECTION_TERMINAL</h2>
          <p className="text-[10px] font-cyber text-slate-500 mt-1 tracking-[0.3em]">BOOST_LEARNING_EFFICIENCY_VIA_METACOGNITION</p>
        </div>
        <div className="flex items-center gap-4 bg-emerald-500/10 border border-emerald-500/20 px-4 py-2 rounded-xl">
          <div className="text-right">
            <div className="text-[8px] font-cyber text-slate-500 uppercase">Current_Efficiency</div>
            <div className="text-lg font-cyber text-emerald-400">x{character.learningEfficiency.toFixed(2)}</div>
          </div>
          <Sparkles size={20} className="text-emerald-400 animate-pulse" />
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <form onSubmit={handleSubmit} className="space-y-6 bg-black/40 border border-emerald-900/20 p-8 rounded-[32px]">
          <div className="space-y-2">
            <label className="text-[10px] font-cyber text-emerald-500 uppercase flex items-center gap-2">
              <MessageSquare size={12} /> Reflection_Content
            </label>
            <textarea 
              value={content}
              onChange={e => setContent(e.target.value)}
              placeholder="What did you learn today? What were the key events?"
              className="w-full h-32 bg-emerald-950/10 border border-emerald-500/20 rounded-2xl p-4 text-xs font-cyber text-emerald-100 placeholder:text-emerald-900/30 outline-none focus:border-emerald-500/50 transition-all resize-none"
            />
          </div>

          <div className="space-y-2">
            <label className="text-[10px] font-cyber text-emerald-500 uppercase flex items-center gap-2">
              <Brain size={12} /> Mistake_Analysis_&_Optimization
            </label>
            <textarea 
              value={analysis}
              onChange={e => setAnalysis(e.target.value)}
              placeholder="What went wrong? How can you optimize your neural patterns for next time?"
              className="w-full h-32 bg-emerald-950/10 border border-emerald-500/20 rounded-2xl p-4 text-xs font-cyber text-emerald-100 placeholder:text-emerald-900/30 outline-none focus:border-emerald-500/50 transition-all resize-none"
            />
          </div>

          <button 
            type="submit" 
            disabled={isSubmitting}
            className="w-full py-4 bg-emerald-600 hover:bg-emerald-500 text-white font-cyber tracking-[0.2em] rounded-2xl transition-all shadow-lg shadow-emerald-900/40 flex items-center justify-center gap-2"
          >
            {isSubmitting ? 'SYNCING...' : <><Save size={18} /> COMMIT_TO_LONG_TERM_MEMORY</>}
          </button>
        </form>

        <div className="space-y-6">
          <h3 className="font-cyber text-xs text-slate-500 uppercase flex items-center gap-2">
            <History size={14} /> Neural_History
          </h3>
          <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
            {character.reflections.length === 0 ? (
              <div className="py-20 text-center border border-dashed border-emerald-900/20 rounded-3xl opacity-30">
                <p className="font-cyber text-xs text-emerald-900 uppercase">No_Reflections_Logged</p>
              </div>
            ) : (
              character.reflections.map(log => (
                <div key={log.id} className="bg-white/5 border border-white/10 p-6 rounded-3xl space-y-4 hover:border-emerald-500/30 transition-all">
                  <div className="flex justify-between items-center border-b border-white/5 pb-2">
                    <span className="text-[8px] font-cyber text-emerald-500">{new Date(log.date).toLocaleDateString()}</span>
                    <span className="text-[8px] font-cyber text-slate-600 uppercase">Node_{log.id.slice(0,4)}</span>
                  </div>
                  <div className="space-y-2">
                    <div className="text-[8px] font-cyber text-slate-500 uppercase">Experience</div>
                    <p className="text-[10px] font-cyber text-white leading-relaxed">{log.content}</p>
                  </div>
                  <div className="space-y-2 pt-2 border-t border-white/5">
                    <div className="text-[8px] font-cyber text-emerald-900 uppercase">Analysis</div>
                    <p className="text-[10px] font-cyber text-emerald-200/70 leading-relaxed italic">{log.analysis}</p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReflectionLogView;
