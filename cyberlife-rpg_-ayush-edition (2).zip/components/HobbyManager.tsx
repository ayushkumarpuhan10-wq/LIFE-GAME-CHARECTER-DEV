
import React, { useState } from 'react';
import { Hobby } from '../types';
import { Plus, Zap, Star } from 'lucide-react';

interface HobbyManagerProps {
  hobbies: Hobby[];
  setHobbies: React.Dispatch<React.SetStateAction<Hobby[]>>;
  onXPGain: (xp: number) => void;
}

const HobbyManager: React.FC<HobbyManagerProps> = ({ hobbies, setHobbies, onXPGain }) => {
  const [newHobbyName, setNewHobbyName] = useState('');

  const addHobby = () => {
    if (!newHobbyName) return;
    const hobby: Hobby = {
      id: Math.random().toString(36).substr(2, 9),
      name: newHobbyName,
      level: 1,
      xp: 0
    };
    setHobbies([...hobbies, hobby]);
    setNewHobbyName('');
  };

  const trainHobby = (id: string) => {
    setHobbies(prev => prev.map(h => {
      if (h.id === id) {
        const newXP = h.xp + 20;
        const newLevel = Math.floor(newXP / 100) + 1;
        onXPGain(10);
        return { ...h, xp: newXP, level: newLevel };
      }
      return h;
    }));
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h2 className="font-cyber text-xl text-purple-400 neon-text-purple">NEURAL_PROTOCOLS</h2>
        <div className="flex gap-2 w-full md:w-auto">
          <input 
            type="text" 
            placeholder="New skill protocol..."
            value={newHobbyName}
            onChange={e => setNewHobbyName(e.target.value)}
            className="bg-black border border-blue-900 p-2 text-sm text-blue-400 outline-none rounded-lg flex-1"
          />
          <button onClick={addHobby} className="p-2 bg-blue-500 text-black rounded-lg">
            <Plus size={20} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {hobbies.map(hobby => {
          const progress = (hobby.xp % 100);
          return (
            <div key={hobby.id} className="p-6 border border-blue-900/30 bg-black/40 rounded-2xl hover:neon-border-blue transition-all group">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-cyber text-lg text-blue-100 group-hover:text-blue-400 transition-colors">{hobby.name}</h3>
                  <span className="text-[10px] font-cyber text-purple-400">MASTERY_LVL: {hobby.level}</span>
                </div>
                <div className="bg-purple-900/20 p-2 rounded-lg text-purple-400">
                  <Star size={20} />
                </div>
              </div>

              <div className="space-y-2 mb-6">
                <div className="flex justify-between text-[10px] font-cyber text-slate-500">
                  <span>PROGRESS</span>
                  <span>{progress}/100</span>
                </div>
                <div className="h-2 w-full bg-blue-900/20 rounded-full overflow-hidden">
                  <div className="h-full bg-purple-500 shadow-[0_0_10px_#bc13fe]" style={{ width: `${progress}%` }}></div>
                </div>
              </div>

              <button 
                onClick={() => trainHobby(hobby.id)}
                className="w-full py-2 bg-blue-500/10 hover:bg-blue-500 text-blue-400 hover:text-black border border-blue-500/30 font-cyber text-xs rounded transition-all flex items-center justify-center gap-2"
              >
                <Zap size={14} /> INITIALIZE_TRAINING_CYCLE
              </button>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default HobbyManager;
