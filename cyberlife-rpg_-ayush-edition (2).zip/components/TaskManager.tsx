
import React, { useState } from 'react';
import { Task, TaskCategory, FocusQuality } from '../types';
import { Plus, Trash2, CheckCircle, Clock, Calendar as CalIcon, Zap, Target, AlertCircle } from 'lucide-react';

interface TaskManagerProps {
  tasks: Task[];
  onAddTask: (task: any) => void;
  onCompleteTask: (id: string, focusQuality: FocusQuality) => void;
  onDeleteTask: (id: string) => void;
}

const TaskManager: React.FC<TaskManagerProps> = ({ tasks, onAddTask, onCompleteTask, onDeleteTask }) => {
  const [showAdd, setShowAdd] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    category: TaskCategory.WORK,
    startTime: '09:00',
    endTime: '10:00',
    date: new Date().toISOString().split('T')[0]
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.title) return;
    onAddTask(formData);
    setShowAdd(false);
    setFormData({ ...formData, title: '' });
  };

  const filteredTasks = tasks.filter(t => t.date === new Date().toISOString().split('T')[0]);

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex justify-between items-center border-b border-blue-900/30 pb-4">
        <h2 className="font-cyber text-xl text-blue-400 neon-text-blue">DAILY_OBJECTIVES</h2>
        <button 
          onClick={() => setShowAdd(!showAdd)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-500 hover:bg-blue-400 text-black font-cyber text-xs rounded transition-all neon-border-blue"
        >
          <Plus size={16} /> INITIALIZE_NEW_TASK
        </button>
      </div>

      {showAdd && (
        <form onSubmit={handleSubmit} className="p-6 border border-blue-500/50 bg-blue-950/20 rounded-xl space-y-4 animate-in fade-in slide-in-from-top-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-[10px] font-cyber text-blue-400">TASK_IDENTIFIER</label>
              <input 
                type="text" 
                value={formData.title}
                onChange={e => setFormData({...formData, title: e.target.value})}
                className="w-full bg-black border border-blue-900 p-2 text-blue-400 focus:border-blue-500 outline-none rounded"
                placeholder="Ex: Morning Workout"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-cyber text-blue-400">DATA_CATEGORY</label>
              <select 
                value={formData.category}
                onChange={e => setFormData({...formData, category: e.target.value as TaskCategory})}
                className="w-full bg-black border border-blue-900 p-2 text-blue-400 focus:border-blue-500 outline-none rounded"
              >
                {Object.values(TaskCategory).map(cat => (
                  <option key={cat} value={cat}>{cat}</option>
                ))}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-cyber text-blue-400">TEMPORAL_START</label>
              <input 
                type="time" 
                value={formData.startTime}
                onChange={e => setFormData({...formData, startTime: e.target.value})}
                className="w-full bg-black border border-blue-900 p-2 text-blue-400 focus:border-blue-500 outline-none rounded"
              />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-cyber text-blue-400">TEMPORAL_END</label>
              <input 
                type="time" 
                value={formData.endTime}
                onChange={e => setFormData({...formData, endTime: e.target.value})}
                className="w-full bg-black border border-blue-900 p-2 text-blue-400 focus:border-blue-500 outline-none rounded"
              />
            </div>
          </div>
          <button type="submit" className="w-full py-3 bg-purple-600 hover:bg-purple-500 text-white font-cyber tracking-widest rounded-xl transition-all neon-border-purple mt-4">
            UPLOAD_TO_CORE
          </button>
        </form>
      )}

      <div className="space-y-4">
        {filteredTasks.length === 0 ? (
          <div className="py-20 text-center border border-dashed border-blue-900/30 rounded-2xl">
            <span className="font-cyber text-slate-600 text-sm italic">NO_ACTIVE_TRANSMISSIONS_FOUND</span>
          </div>
        ) : (
          filteredTasks.sort((a,b) => a.startTime.localeCompare(b.startTime)).map(task => (
            <div key={task.id} className={`group flex flex-col md:flex-row items-center justify-between p-4 border border-blue-900/30 bg-black/60 rounded-xl hover:border-blue-500/50 transition-all ${task.completed ? 'opacity-60 bg-green-500/5 border-green-900/30' : ''}`}>
              <div className="flex items-center gap-4 w-full md:w-auto">
                <div className={`p-3 rounded-lg ${task.completed ? 'bg-green-500/20 text-green-500' : 'bg-blue-500/10 text-blue-400'}`}>
                  {task.completed ? <CheckCircle size={24} /> : <Clock size={24} />}
                </div>
                <div>
                  <h3 className={`font-cyber text-lg ${task.completed ? 'line-through text-slate-500' : 'text-blue-100'}`}>{task.title}</h3>
                  <div className="flex items-center gap-4 text-[10px] font-cyber mt-1">
                    <span className="text-purple-400 px-2 py-0.5 border border-purple-900/50 rounded bg-purple-950/20">{task.category}</span>
                    <span className="text-blue-500">{task.startTime} — {task.endTime}</span>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center gap-4 mt-4 md:mt-0 w-full md:w-auto justify-end">
                <div className="text-right px-4">
                  <div className="text-[10px] font-cyber text-slate-600 uppercase">XP Reward</div>
                  <div className="font-cyber text-blue-400">+{task.xp}</div>
                </div>
                {!task.completed && (
                  <div className="flex items-center gap-1 bg-black/40 p-1 rounded-lg border border-white/5">
                    <button 
                      onClick={() => onCompleteTask(task.id, 'deep')}
                      className="px-3 py-2 bg-emerald-600/20 hover:bg-emerald-600 text-emerald-400 hover:text-white rounded transition-all flex flex-col items-center gap-0.5"
                      title="Deep Focus (2x XP)"
                    >
                      <Zap size={14} />
                      <span className="text-[6px] font-cyber">DEEP</span>
                    </button>
                    <button 
                      onClick={() => onCompleteTask(task.id, 'standard')}
                      className="px-3 py-2 bg-blue-600/20 hover:bg-blue-600 text-blue-400 hover:text-white rounded transition-all flex flex-col items-center gap-0.5"
                      title="Standard Focus (1x XP)"
                    >
                      <Target size={14} />
                      <span className="text-[6px] font-cyber">STD</span>
                    </button>
                    <button 
                      onClick={() => onCompleteTask(task.id, 'distracted')}
                      className="px-3 py-2 bg-orange-600/20 hover:bg-orange-600 text-orange-400 hover:text-white rounded transition-all flex flex-col items-center gap-0.5"
                      title="Distracted (0.5x XP)"
                    >
                      <AlertCircle size={14} />
                      <span className="text-[6px] font-cyber">DIST</span>
                    </button>
                  </div>
                )}
                <button 
                  onClick={() => onDeleteTask(task.id)}
                  className="p-3 bg-red-900/20 hover:bg-red-500 text-red-500 hover:text-white rounded-lg transition-all"
                  title="Abort Task"
                >
                  <Trash2 size={20} />
                </button>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default TaskManager;
