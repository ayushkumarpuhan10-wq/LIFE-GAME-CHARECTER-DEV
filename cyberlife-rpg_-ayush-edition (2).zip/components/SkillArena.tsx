
import React, { useState, useEffect } from 'react';
import { SkillType, Character } from '../types';
import { ShieldCheck, Zap, AlertTriangle, Target, Brain, Dumbbell, MessageSquare, Code } from 'lucide-react';

interface SkillArenaProps {
  character: Character;
  onCompleteTest: (skillType: SkillType, success: boolean) => void;
}

const SkillArena: React.FC<SkillArenaProps> = ({ character, onCompleteTest }) => {
  const [activeTest, setActiveTest] = useState<SkillType | null>(null);
  const [timeLeft, setTimeLeft] = useState(30);
  const [score, setScore] = useState(0);
  const [isTesting, setIsTesting] = useState(false);
  const [targetValue, setTargetValue] = useState(0);

  useEffect(() => {
    let timer: any;
    if (isTesting && timeLeft > 0) {
      timer = setInterval(() => setTimeLeft(prev => prev - 1), 1000);
    } else if (timeLeft === 0) {
      setIsTesting(false);
      onCompleteTest(activeTest!, score >= 10);
    }
    return () => clearInterval(timer);
  }, [isTesting, timeLeft]);

  const startTest = (type: SkillType) => {
    setActiveTest(type);
    setIsTesting(true);
    setTimeLeft(30);
    setScore(0);
    setTargetValue(Math.floor(Math.random() * 100));
  };

  const handleAction = () => {
    if (!isTesting) return;
    setScore(prev => prev + 1);
    setTargetValue(Math.floor(Math.random() * 100));
  };

  if (isTesting) {
    return (
      <div className="fixed inset-0 bg-black/90 backdrop-blur-2xl z-[100] flex items-center justify-center p-8">
        <div className="max-w-2xl w-full bg-blue-950/20 border border-blue-500/30 rounded-[48px] p-12 text-center space-y-8 relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-1 bg-blue-500/20">
            <div className="h-full bg-blue-500 transition-all duration-1000" style={{ width: `${(timeLeft / 30) * 100}%` }} />
          </div>
          
          <div className="space-y-2">
            <h2 className="font-cyber text-3xl text-blue-400 neon-text-blue uppercase tracking-widest">Neural_Stress_Test</h2>
            <p className="text-[10px] font-cyber text-slate-500 uppercase">Skill: {activeTest}</p>
          </div>

          <div className="grid grid-cols-2 gap-8">
            <div className="bg-black/40 border border-white/5 p-6 rounded-3xl">
              <div className="text-[8px] font-cyber text-slate-500 uppercase mb-2">Time_Remaining</div>
              <div className="text-4xl font-cyber text-white tabular-nums">{timeLeft}s</div>
            </div>
            <div className="bg-black/40 border border-white/5 p-6 rounded-3xl">
              <div className="text-[8px] font-cyber text-slate-500 uppercase mb-2">Neural_Sync_Score</div>
              <div className="text-4xl font-cyber text-emerald-400 tabular-nums">{score} / 10</div>
            </div>
          </div>

          <div className="py-12">
             <button 
               onClick={handleAction}
               className="w-48 h-48 rounded-full border-4 border-blue-500/30 bg-blue-500/10 flex items-center justify-center group hover:bg-blue-500/20 hover:border-blue-500 transition-all active:scale-95 shadow-[0_0_50px_rgba(0,243,255,0.1)]"
             >
               <Zap size={64} className="text-blue-400 group-hover:scale-110 transition-transform" />
             </button>
             <p className="text-[10px] font-cyber text-slate-600 mt-6 uppercase tracking-[0.5em] animate-pulse">Rapid_Input_Required</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="text-center space-y-4">
        <h2 className="font-cyber text-3xl text-purple-400 neon-text-purple uppercase tracking-widest">Skill_Test_Arena</h2>
        <p className="text-xs font-cyber text-slate-500 max-w-lg mx-auto leading-relaxed">
          Monthly evaluation protocols are now active. Prove your mastery in specific neural domains to earn massive XP rewards. <span className="text-red-500 font-bold">WARNING: NO RETRIES ALLOWED.</span>
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {Object.values(SkillType).map(type => (
          <div key={type} className="bg-black/40 border border-purple-900/20 p-8 rounded-[32px] flex flex-col items-center text-center group hover:border-purple-500/40 transition-all">
            <div className="w-16 h-16 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              {type === SkillType.COGNITIVE && <Brain size={32} className="text-purple-400" />}
              {type === SkillType.PHYSICAL && <Dumbbell size={32} className="text-purple-400" />}
              {type === SkillType.COMMUNICATION && <MessageSquare size={32} className="text-purple-400" />}
              {type === SkillType.TECHNICAL && <Code size={32} className="text-purple-400" />}
              {type === SkillType.EMOTIONAL && <ShieldCheck size={32} className="text-purple-400" />}
            </div>
            <h3 className="font-cyber text-lg text-white mb-2 uppercase tracking-tighter">{type}</h3>
            <p className="text-[8px] font-cyber text-slate-600 uppercase mb-6">Current_Rank: {character.skills[type].rank}</p>
            <button 
              onClick={() => startTest(type)}
              className="w-full py-3 bg-purple-600/20 border border-purple-500/30 text-purple-400 font-cyber text-[10px] rounded-xl hover:bg-purple-600 hover:text-white transition-all uppercase tracking-widest"
            >
              Initiate_Test
            </button>
          </div>
        ))}
      </div>

      <div className="bg-red-950/10 border border-red-900/20 p-6 rounded-3xl flex items-center gap-6">
        <AlertTriangle className="text-red-500 shrink-0" size={32} />
        <div>
          <div className="text-[10px] font-cyber text-red-500 uppercase mb-1">System_Warning</div>
          <p className="text-[10px] font-cyber text-slate-500 leading-relaxed uppercase">
            Arena tests are high-stakes simulations. Failure results in zero XP gain and a 30-day lockout for the specific neural domain. Ensure your focus levels are optimal before execution.
          </p>
        </div>
      </div>
    </div>
  );
};

export default SkillArena;
