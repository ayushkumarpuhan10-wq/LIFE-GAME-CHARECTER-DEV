
import React from 'react';
import { Radar, RadarChart, PolarGrid, PolarAngleAxis, ResponsiveContainer } from 'recharts';
import { RPGStats } from '../types';

interface StatsViewProps {
  stats: RPGStats;
}

const StatsView: React.FC<StatsViewProps> = ({ stats }) => {
  const data = [
    { subject: 'Mental Health', A: stats.mentalHealth, fullMark: 150 },
    { subject: 'Discipline', A: stats.discipline, fullMark: 150 },
    { subject: 'Health', A: stats.health, fullMark: 150 },
    { subject: 'Work', A: stats.work, fullMark: 150 },
    { subject: 'Study', A: stats.study, fullMark: 150 },
    { subject: 'Hobbies', A: stats.hobbies, fullMark: 150 },
  ];

  return (
    <div className="max-w-4xl mx-auto">
       <h2 className="font-cyber text-xl text-blue-400 neon-text-blue mb-8 text-center">BIOMETRIC_MATRIX</h2>
       
       <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
         <div className="h-[400px] w-full border border-blue-900/30 rounded-2xl bg-black/40 p-4">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="80%" data={data}>
                <PolarGrid stroke="#1e40af" strokeDasharray="3 3" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#60a5fa', fontSize: 10, fontFamily: 'Orbitron' }} />
                <Radar
                  name="Ayush"
                  dataKey="A"
                  stroke="#bc13fe"
                  fill="#bc13fe"
                  fillOpacity={0.4}
                />
              </RadarChart>
            </ResponsiveContainer>
         </div>

         <div className="grid grid-cols-2 gap-4">
           {data.map(item => (
             <div key={item.subject} className="p-4 border border-blue-900/30 bg-blue-950/10 rounded-xl">
               <div className="text-[10px] font-cyber text-slate-500 mb-1">{item.subject.toUpperCase()}</div>
               <div className="flex items-end justify-between">
                 <span className="text-2xl font-cyber text-blue-400 neon-text-blue">{item.A}</span>
                 <span className="text-[10px] font-cyber text-slate-700">RANK_S</span>
               </div>
               <div className="mt-2 h-1 w-full bg-blue-900/20 rounded-full overflow-hidden">
                 <div className="h-full bg-blue-400" style={{ width: `${(item.A / 150) * 100}%` }}></div>
               </div>
             </div>
           ))}
         </div>
       </div>

       <div className="mt-8 p-6 border border-purple-500/30 bg-purple-950/5 rounded-xl text-center">
         <p className="font-cyber text-xs text-purple-400 leading-relaxed italic uppercase">
           "YOUR NEURAL PLASTICITY IS CURRENTLY AT PEAK PERFORMANCE. MAINTAIN PROTOCOLS TO PREVENT SYSTEM DEGRADATION."
         </p>
       </div>
    </div>
  );
};

export default StatsView;
