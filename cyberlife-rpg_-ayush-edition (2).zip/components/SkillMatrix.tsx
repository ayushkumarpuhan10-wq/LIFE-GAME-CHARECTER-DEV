
import React from 'react';
import { SkillType, SkillRank, SkillProgression, Character } from '../types';
import { Brain, Dumbbell, MessageSquare, Code, ShieldCheck, ChevronRight, TrendingUp, AlertTriangle, Zap } from 'lucide-react';

interface SkillMatrixProps {
  character: Character;
}

const SkillMatrix: React.FC<SkillMatrixProps> = ({ character }) => {
  const skills = Object.values(character.skills) as SkillProgression[];

  const getSkillIcon = (type: SkillType) => {
    switch (type) {
      case SkillType.COGNITIVE: return <Brain size={20} />;
      case SkillType.PHYSICAL: return <Dumbbell size={20} />;
      case SkillType.COMMUNICATION: return <MessageSquare size={20} />;
      case SkillType.TECHNICAL: return <Code size={20} />;
      case SkillType.EMOTIONAL: return <ShieldCheck size={20} />;
    }
  };

  const getRankColor = (rank: SkillRank) => {
    switch (rank) {
      case SkillRank.NOVICE: return 'text-slate-500';
      case SkillRank.APPRENTICE: return 'text-blue-400';
      case SkillRank.SKILLED: return 'text-emerald-400';
      case SkillRank.ADVANCED: return 'text-purple-400';
      case SkillRank.ELITE: return 'text-orange-400';
      case SkillRank.MASTER: return 'text-red-500';
    }
  };

  const getNextThreshold = (xp: number) => {
    const thresholds = [1000, 3000, 7000, 15000, 30000, 100000];
    return thresholds.find(t => t > xp) || 100000;
  };

  const checkDecay = (lastActivity: string) => {
    const last = new Date(lastActivity).getTime();
    const now = new Date().getTime();
    const diffDays = (now - last) / (1000 * 60 * 60 * 24);
    return diffDays > 14;
  };

  const getActiveCombos = () => {
    const combos = [];
    if (character.skills[SkillType.COGNITIVE].rank !== SkillRank.NOVICE && character.skills[SkillType.TECHNICAL].rank !== SkillRank.NOVICE) {
      combos.push({ name: 'Neural_Overclock', bonus: '+10% Technical XP', color: 'text-blue-400' });
    }
    if (character.skills[SkillType.PHYSICAL].rank !== SkillRank.NOVICE && character.skills[SkillType.EMOTIONAL].rank !== SkillRank.NOVICE) {
      combos.push({ name: 'Unstoppable_Will', bonus: '+10% Physical XP', color: 'text-emerald-400' });
    }
    return combos;
  };

  const activeCombos = getActiveCombos();

  return (
    <div className="max-w-6xl mx-auto space-y-8 animate-in fade-in duration-500">
      <div className="flex justify-between items-center border-b border-blue-900/30 pb-4">
        <div>
          <h2 className="font-cyber text-2xl text-blue-400 neon-text-blue">SKILL_MATRIX_v4.0</h2>
          <p className="text-[10px] font-cyber text-slate-500 mt-1 tracking-[0.3em]">NEURAL_PROGRESSION_OVERRIDE_ACTIVE</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right">
            <div className="text-[8px] font-cyber text-slate-600 uppercase">Learning_Efficiency</div>
            <div className="text-xl font-cyber text-emerald-400">x{character.learningEfficiency.toFixed(2)}</div>
          </div>
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center">
            <TrendingUp size={24} className="text-emerald-400" />
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
        {skills.map(skill => {
          const nextThreshold = getNextThreshold(skill.xp);
          const prevThreshold = [0, 1000, 3000, 7000, 15000, 30000].reverse().find(t => t <= skill.xp) || 0;
          const progress = ((skill.xp - prevThreshold) / (nextThreshold - prevThreshold)) * 100;
          const isDecaying = checkDecay(skill.lastActivity);

          return (
            <div key={skill.type} className="bg-black/60 border border-blue-900/20 rounded-3xl p-6 flex flex-col relative group hover:border-blue-500/40 transition-all">
              {isDecaying && (
                <div className="absolute -top-2 -right-2 bg-red-600 text-white p-1 rounded-full animate-pulse shadow-lg shadow-red-900/50">
                  <AlertTriangle size={16} />
                </div>
              )}
              
              <div className="flex items-center justify-between mb-6">
                <div className={`p-3 rounded-2xl bg-blue-500/10 border border-blue-500/20 ${getRankColor(skill.rank)}`}>
                  {getSkillIcon(skill.type)}
                </div>
                <div className="text-right">
                  <div className={`text-[10px] font-cyber uppercase tracking-widest ${getRankColor(skill.rank)}`}>{skill.rank}</div>
                  <div className="text-[8px] font-cyber text-slate-600 mt-1">RANK_STATUS</div>
                </div>
              </div>

              <h3 className="font-cyber text-sm text-white mb-2 uppercase tracking-tighter">{skill.type}</h3>
              
              <div className="flex-1 space-y-4">
                <div className="space-y-1">
                  <div className="flex justify-between text-[8px] font-cyber text-slate-500 uppercase">
                    <span>XP_SYNC</span>
                    <span>{skill.xp} / {nextThreshold}</span>
                  </div>
                  <div className="h-1.5 w-full bg-blue-950/20 rounded-full overflow-hidden border border-blue-900/30">
                    <div 
                      className="h-full bg-gradient-to-r from-blue-600 to-blue-400 transition-all duration-1000"
                      style={{ width: `${progress}%` }}
                    />
                  </div>
                </div>

                <div className="space-y-2 pt-4 border-t border-white/5">
                  <div className="text-[8px] font-cyber text-slate-600 uppercase tracking-widest">Sub_Protocols</div>
                  <div className="flex flex-wrap gap-1.5">
                    {skill.subSkills.map(sub => (
                      <span key={sub} className="px-2 py-0.5 bg-white/5 border border-white/10 rounded text-[8px] font-cyber text-slate-400">
                        {sub.toUpperCase()}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between">
                <div className="text-[8px] font-cyber text-slate-600 uppercase">Last_Activity</div>
                <div className="text-[8px] font-cyber text-blue-400">{new Date(skill.lastActivity).toLocaleDateString()}</div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 bg-blue-500/5 border border-blue-500/20 rounded-3xl p-8 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-8 opacity-5"><TrendingUp size={120} /></div>
          <div className="relative z-10">
            <h3 className="font-cyber text-lg text-blue-400 mb-4 flex items-center gap-2">
              <TrendingUp size={20} /> NEURAL_EFFICIENCY_METRICS
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              <div className="space-y-1">
                <div className="text-[8px] font-cyber text-slate-500 uppercase">Total_Skill_XP</div>
                <div className="text-xl font-cyber text-white">{skills.reduce((acc, s) => acc + s.xp, 0)}</div>
              </div>
              <div className="space-y-1">
                <div className="text-[8px] font-cyber text-slate-500 uppercase">Mastery_Ranks</div>
                <div className="text-xl font-cyber text-purple-400">{skills.filter(s => s.rank === SkillRank.MASTER).length}</div>
              </div>
              <div className="space-y-1">
                <div className="text-[8px] font-cyber text-slate-500 uppercase">Active_Protocols</div>
                <div className="text-xl font-cyber text-emerald-400">{skills.filter(s => !checkDecay(s.lastActivity)).length} / 5</div>
              </div>
              <div className="space-y-1">
                <div className="text-[8px] font-cyber text-slate-500 uppercase">Global_Efficiency</div>
                <div className="text-xl font-cyber text-blue-400">{(character.learningEfficiency * 100).toFixed(0)}%</div>
              </div>
            </div>
            
            {activeCombos.length > 0 && (
              <div className="mt-6 pt-6 border-t border-white/5 flex flex-wrap gap-4">
                {activeCombos.map(combo => (
                  <div key={combo.name} className="flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-xl border border-white/10">
                    <Zap size={12} className={combo.color} />
                    <span className={`text-[9px] font-cyber uppercase ${combo.color}`}>{combo.name}</span>
                    <span className="text-[8px] font-cyber text-slate-500">{combo.bonus}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="bg-purple-500/5 border border-purple-500/20 rounded-3xl p-8 flex flex-col justify-center items-center text-center group cursor-pointer hover:bg-purple-500/10 transition-all">
          <div className="w-16 h-16 rounded-2xl bg-purple-500/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
            <ShieldCheck size={32} className="text-purple-400" />
          </div>
          <h3 className="font-cyber text-lg text-purple-400 mb-2">MONTHLY_ARENA</h3>
          <p className="text-[10px] font-cyber text-slate-500 uppercase tracking-widest mb-6">Next Challenge: 2 Days</p>
          <button className="w-full py-3 bg-purple-600 text-white font-cyber text-xs rounded-xl shadow-lg shadow-purple-900/40 hover:bg-purple-500 transition-all">
            ENTER_SIMULATION
          </button>
        </div>
      </div>
    </div>
  );
};

export default SkillMatrix;
