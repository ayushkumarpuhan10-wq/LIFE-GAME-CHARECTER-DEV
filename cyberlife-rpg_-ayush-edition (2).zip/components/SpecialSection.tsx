
import React, { useState, useEffect } from 'react';
import { Play, Pause, RotateCcw, Clock, Music } from 'lucide-react';
import { GlobalToolsState } from '../types';
import AmbiancePlayer from './AmbiancePlayer';

interface SpecialSectionProps {
  toolsState: GlobalToolsState;
  setToolsState: React.Dispatch<React.SetStateAction<GlobalToolsState>>;
}

const SpecialSection: React.FC<SpecialSectionProps> = ({ toolsState, setToolsState }) => {
  const [time, setTime] = useState(new Date());
  const [timerInput, setTimerInput] = useState('0');

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatStopwatch = (ms: number) => {
    const minutes = Math.floor(ms / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    const msecs = Math.floor((ms % 1000) / 10);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}.${msecs.toString().padStart(2, '0')}`;
  };

  const formatTimer = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  return (
    <div className="max-w-4xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
      {/* Real Time Clock */}
      <div className="col-span-1 md:col-span-2 p-8 border border-blue-500/50 bg-blue-500/5 rounded-3xl text-center relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-20"><Clock size={100} /></div>
        <div className="relative z-10">
          <div className="text-[10px] font-cyber text-blue-400 tracking-[0.5em] mb-4 uppercase">System Epoch Time</div>
          <div className="text-6xl md:text-8xl font-cyber text-blue-400 neon-text-blue mb-4">
            {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false })}
          </div>
          <div className="text-lg font-cyber text-purple-400">
            {time.toLocaleDateString(undefined, { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }).toUpperCase()}
          </div>
        </div>
      </div>

      {/* Stopwatch */}
      <div className="p-6 border border-blue-900/30 bg-black/40 rounded-2xl">
        <h3 className="font-cyber text-blue-400 mb-6 flex items-center gap-2">
          <div className="w-1.5 h-4 bg-blue-500"></div> CHRONO_CAPTURE
        </h3>
        <div className="text-4xl font-cyber text-blue-100 text-center mb-8 tabular-nums">
          {formatStopwatch(toolsState.stopwatch.time)}
        </div>
        <div className="flex gap-4">
          <button 
            onClick={() => setToolsState(prev => ({ 
              ...prev, 
              stopwatch: { ...prev.stopwatch, running: !prev.stopwatch.running } 
            }))}
            className={`flex-1 py-3 font-cyber text-xs rounded-xl flex items-center justify-center gap-2 transition-all ${
              toolsState.stopwatch.running ? 'bg-red-500/20 text-red-400 border border-red-500/50' : 'bg-green-500/20 text-green-400 border border-green-500/50'
            }`}
          >
            {toolsState.stopwatch.running ? <><Pause size={16}/> SUSPEND</> : <><Play size={16}/> EXECUTE</>}
          </button>
          <button 
            onClick={() => setToolsState(prev => ({ 
              ...prev, 
              stopwatch: { time: 0, running: false } 
            }))}
            className="px-6 py-3 bg-slate-800 text-slate-400 rounded-xl hover:bg-slate-700 transition-all"
          >
            <RotateCcw size={16} />
          </button>
        </div>
      </div>

      {/* Timer */}
      <div className="p-6 border border-blue-900/30 bg-black/40 rounded-2xl">
        <h3 className="font-cyber text-purple-400 mb-6 flex items-center gap-2">
          <div className="w-1.5 h-4 bg-purple-500"></div> DECAY_SEQUENCE
        </h3>
        <div className="text-4xl font-cyber text-purple-100 text-center mb-6 tabular-nums">
          {formatTimer(toolsState.timer.seconds)}
        </div>
        <div className="space-y-4">
          {!toolsState.timer.running && toolsState.timer.seconds === 0 && (
            <input 
              type="number"
              value={timerInput}
              onChange={e => setTimerInput(e.target.value)}
              placeholder="Seconds..."
              className="w-full bg-black border border-purple-900 p-2 text-center text-purple-400 outline-none rounded"
            />
          )}
          <div className="flex gap-4">
            <button 
              onClick={() => {
                if (toolsState.timer.seconds === 0 && !toolsState.timer.running) {
                  const s = parseInt(timerInput) || 0;
                  setToolsState(prev => ({ 
                    ...prev, 
                    timer: { seconds: s, running: true } 
                  }));
                } else {
                  setToolsState(prev => ({ 
                    ...prev, 
                    timer: { ...prev.timer, running: !prev.timer.running } 
                  }));
                }
              }}
              className={`flex-1 py-3 font-cyber text-xs rounded-xl flex items-center justify-center gap-2 transition-all ${
                toolsState.timer.running ? 'bg-red-500/20 text-red-400 border border-red-500/50' : 'bg-purple-500/20 text-purple-400 border border-purple-500/50'
              }`}
            >
              {toolsState.timer.running ? <><Pause size={16}/> HALT</> : <><Play size={16}/> COMMENCE</>}
            </button>
            <button 
              onClick={() => { setToolsState(prev => ({ ...prev, timer: { seconds: 0, running: false } })); }}
              className="px-6 py-3 bg-slate-800 text-slate-400 rounded-xl hover:bg-slate-700 transition-all"
            >
              <RotateCcw size={16} />
            </button>
          </div>
        </div>
      </div>
      {/* Neural Scratchpad */}
      <div className="col-span-1 md:col-span-2 p-6 border border-emerald-900/30 bg-black/40 rounded-3xl">
        <h3 className="font-cyber text-emerald-400 mb-4 flex items-center gap-2 uppercase tracking-widest">
          <div className="w-1.5 h-4 bg-emerald-500"></div> Neural_Scratchpad
        </h3>
        <textarea 
          placeholder="Dumping volatile data..."
          className="w-full h-40 bg-emerald-950/10 border border-emerald-500/20 rounded-2xl p-4 text-xs font-cyber text-emerald-100 placeholder:text-emerald-900/30 outline-none focus:border-emerald-500/50 transition-all resize-none"
        />
        <div className="mt-2 flex justify-between items-center">
          <span className="text-[8px] font-cyber text-emerald-900 uppercase">Volatile_Memory_Active</span>
          <button className="text-[8px] font-cyber text-emerald-500 hover:text-emerald-400 uppercase border border-emerald-500/20 px-2 py-1 rounded">Clear_Buffer</button>
        </div>
      </div>

      {/* Ambiance Player */}
      <div className="col-span-1 md:col-span-2">
        <AmbiancePlayer />
      </div>
    </div>
  );
};

export default SpecialSection;
