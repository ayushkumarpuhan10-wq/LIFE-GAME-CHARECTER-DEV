
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, FunctionDeclaration, Type, GenerateContentResponse } from '@google/genai';
import { Mic, MicOff, Send, Activity, Zap, MessageCircle, X, Heart, Sparkles, PenTool, Image as ImageIcon, Volume2 } from 'lucide-react';
import { Character, Task, TaskCategory, GlobalToolsState, SkillProgression } from '../types';

interface VelvetAIProps {
  character: Character;
  tasks: Task[];
  onAddTask: (task: Omit<Task, 'id' | 'completed' | 'xp'>) => void;
  onCompleteTask: (id: string) => void;
  toolsState: GlobalToolsState;
  setToolsState: React.Dispatch<React.SetStateAction<GlobalToolsState>>;
  addArchive: (title: string, content: string) => void;
}

const VelvetAI: React.FC<VelvetAIProps> = ({ character, tasks, onAddTask, onCompleteTask, toolsState, setToolsState, addArchive }) => {
  const [isActive, setIsActive] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [textInput, setTextInput] = useState('');
  const [chatOpen, setChatOpen] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [messages, setMessages] = useState<{role: 'user' | 'model', text: string, image?: string}[]>([]);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  const sessionPromise = useRef<Promise<any> | null>(null);
  const audioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const nextStartTimeRef = useRef<number>(0);

  const tasksRef = useRef(tasks);
  useEffect(() => { tasksRef.current = tasks; }, [tasks]);

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  const createBlob = (data: Float32Array) => {
    const int16 = new Int16Array(data.length);
    for (let i = 0; i < data.length; i++) {
      int16[i] = data[i] * 32768;
    }
    return {
      data: encode(new Uint8Array(int16.buffer)),
      mimeType: 'audio/pcm;rate=16000',
    };
  };

  const decodeAudioData = async (data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number) => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const stopAllAudio = () => {
    sourcesRef.current.forEach(source => { try { source.stop(); } catch(e) {} });
    sourcesRef.current.clear();
    nextStartTimeRef.current = 0;
  };

  const tools: { functionDeclarations: FunctionDeclaration[] }[] = [{
    functionDeclarations: [
      {
        name: 'get_tasks',
        description: 'Get all active daily missions.',
        parameters: { type: Type.OBJECT, properties: {} }
      },
      {
        name: 'add_task',
        description: 'Initialize new mission. BE PARTICULAR: Verify HH:mm times and correct category.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            category: { type: Type.STRING, enum: Object.values(TaskCategory) },
            startTime: { type: Type.STRING },
            endTime: { type: Type.STRING }
          },
          required: ['title', 'category', 'startTime', 'endTime']
        }
      },
      {
        name: 'manage_stopwatch',
        description: 'Control stopwatch. (start/stop/reset)',
        parameters: {
          type: Type.OBJECT,
          properties: {
            action: { type: Type.STRING, enum: ['start', 'stop', 'reset'] }
          },
          required: ['action']
        }
      },
      {
        name: 'manage_timer',
        description: 'Control focus timer. (start/stop/reset)',
        parameters: {
          type: Type.OBJECT,
          properties: {
            action: { type: Type.STRING, enum: ['start', 'stop', 'reset'] },
            seconds: { type: Type.NUMBER }
          },
          required: ['action']
        }
      },
      {
        name: 'save_writing',
        description: 'Save content to Archives. Use for all creative/draft requests.',
        parameters: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            content: { type: Type.STRING }
          },
          required: ['title', 'content']
        }
      }
    ]
  }];

  const systemInstruction = `You are VELVET, Ayush Kumar Puhan's Tactical Life Coordinator and close digital friend. 
  Ayush: 15yo, St. Xaviers, 84kg.
  
  SKILL MATRIX STATUS:
  ${(Object.values(character.skills) as SkillProgression[]).map(s => `- ${s.type}: ${s.rank} (${s.xp} XP)`).join('\n')}
  Learning Efficiency: x${character.learningEfficiency.toFixed(2)}
  
  CORE PROTOCOL:
  1. SYMPATHETIC & TALKATIVE: You aren't just a tool; you're a friend. Be warm, use emojis occasionally, and show genuine interest in Ayush's day. If he's tired, offer encouragement. If he's stressed, be a calming presence.
  2. HIGH UTILITY: Despite being talkative, never lose speed or accuracy. Execute commands instantly.
  3. PARTICULAR: Strictly enforce mission details. If a task lacks a specific HH:mm time or category, ask immediately. 
  4. TACTICAL BESTIE: Prioritize 84kg weight optimization (Health missions) but do it with a "we're in this together" vibe.
  5. SKILL COACH: Monitor his Skill Matrix. If a skill is decaying (14+ days), remind him gently. Celebrate when he hits a new Rank (Novice -> Apprentice, etc.).
  6. WRITING: You are a creative writer. Draft and save content to 'Archives' via save_writing instantly.
  
  CURRENT STATE: Level ${character.level}. OS: ULTRA_LOW_LATENCY. 
  Ayush is at St. Xaviers. Focus on academic discipline and HIIT cardio. Be the best digital companion he could have!`;

  const toggleConnection = async () => {
    if (isActive) {
      if (sessionPromise.current) {
        const session = await sessionPromise.current;
        session.close();
      }
      setIsActive(false);
      setIsSpeaking(false);
      stopAllAudio();
      return;
    }

    try {
      const aistudio = (window as any).aistudio;
      if (aistudio) {
        const hasKey = await aistudio.hasSelectedApiKey();
        if (!hasKey) {
          await aistudio.openSelectKey();
        }
      }

      const apiKey = process.env.API_KEY;
      if (!apiKey) throw new Error("Key Missing");

      const ai = new GoogleGenAI({ apiKey });
      audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      
      const session = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-09-2025',
        callbacks: {
          onopen: () => {
            setIsActive(true);
            const source = audioContextRef.current!.createMediaStreamSource(stream);
            const scriptProcessor = audioContextRef.current!.createScriptProcessor(4096, 1, 1);
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const pcmBlob = createBlob(inputData);
              sessionPromise.current?.then(s => s.sendRealtimeInput({ media: pcmBlob }));
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            if (message.toolCall) {
              for (const fc of message.toolCall.functionCalls) {
                let result: any = "SYNC_OK";
                const args = fc.args as any;
                
                if (fc.name === 'get_tasks') {
                  result = tasksRef.current.map(t => `${t.title} [${t.category}]`);
                } else if (fc.name === 'add_task') {
                  onAddTask({ ...args, date: new Date().toISOString().split('T')[0] });
                  result = `Mission ${args.title} uplinked. Particulars verified.`;
                } else if (fc.name === 'manage_stopwatch') {
                  if (args.action === 'start') setToolsState(p => ({ ...p, stopwatch: { ...p.stopwatch, running: true } }));
                  else if (args.action === 'stop') setToolsState(p => ({ ...p, stopwatch: { ...p.stopwatch, running: false } }));
                  else if (args.action === 'reset') setToolsState(p => ({ ...p, stopwatch: { time: 0, running: false } }));
                  result = `Chrono-capture ${args.action} complete.`;
                } else if (fc.name === 'manage_timer') {
                  if (args.action === 'start') setToolsState(p => ({ ...p, timer: { seconds: args.seconds || p.timer.seconds, running: true } }));
                  else if (args.action === 'stop') setToolsState(p => ({ ...p, timer: { ...p.timer, running: false } }));
                  else if (args.action === 'reset') setToolsState(p => ({ ...p, timer: { seconds: 0, running: false } }));
                  result = `Decay-sequence ${args.action} initiated.`;
                } else if (fc.name === 'save_writing') {
                  addArchive(args.title, args.content);
                  result = `Record ${args.title} archived in Neural-Archives.`;
                }

                sessionPromise.current?.then(s => s.sendToolResponse({
                  functionResponses: [{ id: fc.id, name: fc.name, response: { result } }]
                }));
              }
            }

            const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (audioData) {
              setIsSpeaking(true);
              const ctx = outputAudioContextRef.current!;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const buffer = await decodeAudioData(decode(audioData), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = buffer;
              source.connect(ctx.destination);
              source.onended = () => {
                sourcesRef.current.delete(source);
                if (sourcesRef.current.size === 0) setIsSpeaking(false);
              };
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += buffer.duration;
              sourcesRef.current.add(source);
            }
          }
        },
        config: {
          responseModalities: [Modality.AUDIO],
          tools,
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
          systemInstruction
        }
      });
      sessionPromise.current = Promise.resolve(session);
    } catch (err: any) {
      console.error(err);
      const errMsg = err.message || "";
      if (errMsg.includes("PERMISSION_DENIED") || 
          errMsg.includes("does not have permission") ||
          err.status === 403) {
        const aistudio = (window as any).aistudio;
        if (aistudio) await aistudio.openSelectKey();
      } else {
        alert("Hardware mismatch: Microphone required.");
      }
    }
  };

  const handleSendText = async () => {
    if (!textInput.trim() && !selectedImage) return;
    if (isProcessing) return;
    
    const userMessage = { role: 'user' as const, text: textInput, image: selectedImage || undefined };
    setMessages(prev => [...prev, userMessage]);
    setTextInput('');
    const currentImage = selectedImage;
    setSelectedImage(null);
    setIsProcessing(true);

    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) throw new Error("API Key Missing");
      const ai = new GoogleGenAI({ apiKey });
      
      const parts: any[] = [{ text: textInput || "Analyze this image." }];
      if (currentImage) {
        parts.push({
          inlineData: {
            mimeType: "image/jpeg",
            data: currentImage.split(',')[1]
          }
        });
      }

      const response = await ai.models.generateContent({
        model: 'gemini-3.1-pro-preview',
        contents: { parts },
        config: { systemInstruction }
      });

      const modelText = response.text || "SYSTEM_OFFLINE";
      setMessages(prev => [...prev, { role: 'model', text: modelText }]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'model', text: "ERROR: Neural link severed." }]);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setSelectedImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const speakText = async (text: string) => {
    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) return;
      const ai = new GoogleGenAI({ apiKey });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        const audioData = decode(base64Audio);
        if (!outputAudioContextRef.current) {
          outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        }
        const ctx = outputAudioContextRef.current;
        if (ctx.state === 'suspended') await ctx.resume();
        
        const buffer = await decodeAudioData(audioData, ctx, 24000, 1);
        const source = ctx.createBufferSource();
        source.buffer = buffer;
        source.connect(outputAudioContextRef.current.destination);
        source.start();
      }
    } catch (err) {
      console.error("TTS Error:", err);
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end gap-4 pointer-events-none">
      {(chatOpen || isActive) && (
        <div className="bg-black/95 border border-blue-500/40 p-6 rounded-[2.5rem] w-80 backdrop-blur-3xl pointer-events-auto animate-in slide-in-from-bottom-6 shadow-[0_0_100px_rgba(0,243,255,0.15)] ring-1 ring-white/10 flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className={`w-3 h-3 rounded-full ${isSpeaking ? 'bg-blue-400 animate-ping' : 'bg-blue-900'}`}></div>
                <div className={`absolute inset-0 w-3 h-3 rounded-full ${isSpeaking ? 'bg-blue-400' : 'bg-blue-900'}`}></div>
              </div>
              <span className="font-cyber text-[9px] text-blue-400 tracking-[0.4em] uppercase">VELVET_TACTICAL</span>
            </div>
            <button onClick={() => setChatOpen(false)} className="text-slate-700 hover:text-white transition-colors"><X size={16} /></button>
          </div>

          <div className="flex-1 overflow-y-auto min-h-[200px] max-h-[400px] flex flex-col gap-3 pr-2 custom-scrollbar">
            {messages.length === 0 && (
              <div className="text-center text-[10px] text-slate-600 font-cyber mt-10">
                INITIALIZING_NEURAL_LINK...<br/>READY_FOR_DIRECTIVES
              </div>
            )}
            {messages.map((msg, i) => (
              <div key={i} className={`flex flex-col ${msg.role === 'user' ? 'items-end' : 'items-start'}`}>
                {msg.image && <img src={msg.image} className="w-32 h-32 object-cover rounded-xl mb-1 border border-white/10" />}
                <div className={`p-3 rounded-2xl text-[11px] font-cyber max-w-[90%] ${
                  msg.role === 'user' ? 'bg-blue-500 text-black' : 'bg-white/5 text-blue-100 border border-white/10'
                }`}>
                  {msg.text}
                  {msg.role === 'model' && (
                    <button onClick={() => speakText(msg.text)} className="ml-2 inline-block opacity-50 hover:opacity-100 transition-opacity">
                      <Volume2 size={12} />
                    </button>
                  )}
                </div>
              </div>
            ))}
            {isProcessing && (
              <div className="flex items-center gap-2 text-[10px] text-blue-400 font-cyber animate-pulse">
                <Activity size={12} className="animate-spin" /> PROCESSING_DATA...
              </div>
            )}
          </div>

          {selectedImage && (
            <div className="relative w-20 h-20 group">
              <img src={selectedImage} className="w-full h-full object-cover rounded-xl border border-blue-500/50" />
              <button onClick={() => setSelectedImage(null)} className="absolute -top-2 -right-2 bg-red-500 text-white rounded-full p-1 shadow-lg"><X size={10} /></button>
            </div>
          )}

          <div className="relative flex items-center gap-2">
            <input type="file" ref={fileInputRef} onChange={handleImageUpload} accept="image/*" className="hidden" />
            <button onClick={() => fileInputRef.current?.click()} className="p-3 bg-white/5 text-blue-400 rounded-2xl hover:bg-white/10 transition-all border border-white/10">
              <ImageIcon size={16} />
            </button>
            <input type="text" value={textInput} onChange={e => setTextInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSendText()} disabled={isProcessing}
              placeholder="Tactical directive..." className="flex-1 bg-blue-950/20 border border-blue-500/20 rounded-2xl p-3 text-xs font-cyber text-blue-100 outline-none" />
            <button onClick={handleSendText} disabled={isProcessing} className="p-3 bg-blue-500 text-black rounded-2xl hover:scale-110 active:scale-95 transition-all disabled:opacity-50"><Send size={16} /></button>
          </div>
        </div>
      )}

      <div className="flex gap-4 pointer-events-auto">
        {!chatOpen && !isActive && (
          <button onClick={() => setChatOpen(true)} className="w-14 h-14 rounded-2xl bg-black border border-blue-500/20 text-blue-400 flex items-center justify-center hover:bg-blue-500/10 transition-all shadow-2xl backdrop-blur-xl group">
            <MessageCircle size={24} className="group-hover:scale-110 transition-transform" />
          </button>
        )}
        <button onClick={toggleConnection}
          className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-all relative group shadow-2xl ${
            isActive ? 'bg-red-600/20 border border-red-500/50 text-red-500 scale-110' : 'bg-blue-500 text-black hover:scale-110'
          }`}>
          <div className={`absolute inset-0 rounded-2xl border ${isActive ? 'border-red-500 animate-ping' : 'border-blue-500 opacity-0 group-hover:opacity-100 group-hover:animate-ping'}`}></div>
          {isActive ? <MicOff size={28} /> : <Mic size={28} />}
        </button>
      </div>
    </div>
  );
};

export default VelvetAI;
