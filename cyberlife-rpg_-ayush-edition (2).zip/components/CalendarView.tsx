
import React, { useState } from 'react';
import { Task, TaskCategory } from '../types';
import { ChevronLeft, ChevronRight, Zap, Target, AlertCircle, Info, Calendar as CalIcon } from 'lucide-react';

interface CalendarViewProps {
  tasks: Task[];
}

const CalendarView: React.FC<CalendarViewProps> = ({ tasks }) => {
  const [viewDate, setViewDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  
  const days = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
  const startOfMonth = new Date(viewDate.getFullYear(), viewDate.getMonth(), 1);
  const endOfMonth = new Date(viewDate.getFullYear(), viewDate.getMonth() + 1, 0);
  
  const dates = [];
  for (let i = 0; i < startOfMonth.getDay(); i++) dates.push(null);
  for (let i = 1; i <= endOfMonth.getDate(); i++) dates.push(new Date(viewDate.getFullYear(), viewDate.getMonth(), i));

  const getTasksForDate = (date: Date) => {
    const dStr = date.toISOString().split('T')[0];
    return tasks.filter(t => t.date === dStr);
  };

  const getCategoryColor = (cat: TaskCategory) => {
    switch(cat) {
      case TaskCategory.WORK: return 'border-blue-500 text-blue-400 bg-blue-500/10';
      case TaskCategory.HEALTH: return 'border-emerald-500 text-emerald-400 bg-emerald-500/10';
      case TaskCategory.STUDY: return 'border-purple-500 text-purple-400 bg-purple-500/10';
      case TaskCategory.MENTAL_HEALTH: return 'border-pink-500 text-pink-400 bg-pink-500/10';
      case TaskCategory.DISCIPLINE: return 'border-orange-500 text-orange-400 bg-orange-500/10';
      default: return 'border-slate-500 text-slate-400 bg-slate-500/10';
    }
  };

  const changeMonth = (offset: number) => {
    setViewDate(new Date(viewDate.getFullYear(), viewDate.getMonth() + offset, 1));
  };

  return (
    <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-4 gap-8">
      <div className="lg:col-span-3 space-y-6">
        <div className="flex justify-between items-center border-b border-blue-900/30 pb-4">
          <div className="flex items-center gap-4">
            <h2 className="font-cyber text-xl text-blue-400 neon-text-blue">MISSION_LOG</h2>
            <div className="flex items-center gap-1">
              <button onClick={() => changeMonth(-1)} className="p-1 hover:bg-white/5 rounded text-slate-500"><ChevronLeft size={16}/></button>
              <button onClick={() => changeMonth(1)} className="p-1 hover:bg-white/5 rounded text-slate-500"><ChevronRight size={16}/></button>
            </div>
          </div>
          <span className="font-cyber text-purple-400 text-sm tracking-widest">
            {viewDate.toLocaleString('default', { month: 'long', year: 'numeric' }).toUpperCase()}
          </span>
        </div>

        <div className="grid grid-cols-7 gap-1 md:gap-2">
          {days.map(day => (
            <div key={day} className="p-2 text-center text-[10px] font-cyber text-slate-600">{day}</div>
          ))}
          {dates.map((date, idx) => {
            const dateTasks = date ? getTasksForDate(date) : [];
            const isToday = date && date.toDateString() === new Date().toDateString();
            const isSelected = date && selectedDate && date.toDateString() === selectedDate.toDateString();

            return (
              <div 
                key={idx} 
                onClick={() => date && setSelectedDate(date)}
                className={`min-h-[110px] border p-2 rounded-xl transition-all cursor-pointer relative group ${
                  date ? 'bg-black/40 hover:border-blue-500/50' : 'opacity-0 pointer-events-none'
                } ${
                  isToday ? 'border-purple-500 bg-purple-500/5' : 'border-blue-900/20'
                } ${
                  isSelected ? 'ring-2 ring-blue-400 border-blue-400' : ''
                }`}
              >
                {date && (
                  <>
                    <div className={`text-[10px] font-cyber mb-2 flex justify-between items-center ${isToday ? 'text-purple-400' : 'text-slate-500'}`}>
                      <span>{date.getDate()}</span>
                      {dateTasks.some(t => t.focusQuality === 'deep') && <Zap size={8} className="text-emerald-400 animate-pulse" />}
                    </div>
                    <div className="space-y-1">
                      {dateTasks.slice(0, 3).map(task => (
                        <div key={task.id} className={`text-[7px] font-cyber px-1.5 py-0.5 rounded border truncate ${getCategoryColor(task.category)}`}>
                          {task.title}
                        </div>
                      ))}
                      {dateTasks.length > 3 && (
                        <div className="text-[7px] font-cyber text-slate-600 text-center pt-1">
                          +{dateTasks.length - 3} MORE
                        </div>
                      )}
                    </div>
                  </>
                )}
              </div>
            );
          })}
        </div>
      </div>

      <div className="lg:col-span-1 space-y-6">
        <div className="bg-black/60 border border-blue-900/30 rounded-[32px] p-6 h-full flex flex-col">
          <h3 className="font-cyber text-xs text-blue-400 mb-6 flex items-center gap-2 uppercase tracking-widest">
            <Info size={14} /> Mission_Details
          </h3>
          
          {selectedDate ? (
            <div className="flex-1 space-y-6 animate-in fade-in slide-in-from-bottom-4">
              <div>
                <div className="text-[10px] font-cyber text-slate-500 uppercase mb-1">Temporal_Node</div>
                <div className="text-sm font-cyber text-white">{selectedDate.toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' }).toUpperCase()}</div>
              </div>

              <div className="space-y-3">
                <div className="text-[10px] font-cyber text-slate-500 uppercase">Active_Transmissions</div>
                {getTasksForDate(selectedDate).length === 0 ? (
                  <div className="text-[10px] font-cyber text-slate-700 italic">NO_DATA_FOUND</div>
                ) : (
                  getTasksForDate(selectedDate).map(task => (
                    <div key={task.id} className="p-3 bg-white/5 border border-white/10 rounded-xl space-y-2">
                      <div className="flex justify-between items-start">
                        <span className="text-[10px] font-cyber text-blue-200 leading-tight">{task.title}</span>
                        {task.focusQuality === 'deep' && <Zap size={10} className="text-emerald-400" />}
                      </div>
                      <div className="flex justify-between items-center">
                        <span className={`text-[7px] font-cyber px-1.5 py-0.5 rounded border ${getCategoryColor(task.category)}`}>{task.category}</span>
                        <span className="text-[8px] font-cyber text-slate-500">{task.startTime}</span>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          ) : (
            <div className="flex-1 flex flex-col items-center justify-center text-center opacity-30">
              <CalIcon size={40} className="text-blue-900 mb-4" />
              <p className="text-[10px] font-cyber text-blue-900 uppercase tracking-widest">Select_Node_To_Inspect</p>
            </div>
          )}

          <div className="mt-auto pt-6 border-t border-white/5">
             <div className="bg-emerald-500/5 border border-emerald-500/20 p-4 rounded-2xl">
                <div className="text-[8px] font-cyber text-emerald-500 uppercase mb-2">AI_Productivity_Pulse</div>
                <p className="text-[9px] font-cyber text-emerald-200 leading-relaxed italic">"Your neural sync is peaking in the 09:00 - 11:00 window. Schedule high-complexity tasks there."</p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CalendarView;
