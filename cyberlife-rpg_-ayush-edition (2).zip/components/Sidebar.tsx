
import React from 'react';
import { LayoutGrid, Calendar, Target, Shield, Zap, User, MessageSquare, PenTool, BrainCircuit, Sparkles, Swords, MapPin } from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: any) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeTab, setActiveTab }) => {
  const menuItems = [
    { id: 'profile', icon: User, label: 'Profile' },
    { id: 'tasks', icon: Target, label: 'Tasks' },
    { id: 'skills', icon: BrainCircuit, label: 'Skill Matrix' },
    { id: 'arena', icon: Swords, label: 'Arena' },
    { id: 'recon', icon: MapPin, label: 'Recon' },
    { id: 'reflections', icon: Sparkles, label: 'Reflections' },
    { id: 'nexus', icon: MessageSquare, label: 'Nexus Chat' },
    { id: 'archives', icon: PenTool, label: 'Archives' },
    { id: 'calendar', icon: Calendar, label: 'Schedule' },
    { id: 'stats', icon: Shield, label: 'Matrix' },
    { id: 'hobbies', icon: Zap, label: 'Protocols' },
    { id: 'tools', icon: LayoutGrid, label: 'Utility' },
  ];

  return (
    <aside className="w-20 md:w-64 bg-black/90 border-r border-blue-500/20 flex flex-col items-center py-8 gap-12 transition-all duration-300 backdrop-blur-xl relative z-50">
      <div className="absolute inset-y-0 right-0 w-[1px] bg-gradient-to-b from-transparent via-blue-500/50 to-transparent"></div>
      
      <div className="flex flex-col items-center group cursor-pointer">
        <div className="w-14 h-14 bg-blue-500/10 rounded-xl flex items-center justify-center border border-blue-500/30 shadow-[0_0_20px_rgba(var(--glow-rgb),0.2)] mb-3 rotate-45 group-hover:rotate-90 transition-all duration-500">
          <Shield className="-rotate-45 text-blue-400 group-hover:rotate-45 transition-all" size={24} />
        </div>
        <div className="flex flex-col items-center">
          <span className="font-cyber text-[10px] neon-text tracking-[0.3em] hidden md:block">CYBER_SYS</span>
          <span className="text-[7px] font-mono text-slate-600 hidden md:block mt-1">v4.2.0_STABLE</span>
        </div>
      </div>

      <nav className="flex flex-col gap-2 w-full px-4 overflow-y-auto custom-scrollbar flex-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`flex items-center gap-4 p-3 rounded-xl transition-all relative group overflow-hidden ${
                isActive 
                ? 'bg-blue-500/10 text-blue-400 border border-blue-500/30 shadow-[inset_0_0_10px_rgba(var(--glow-rgb),0.1)]' 
                : 'text-slate-500 hover:text-white hover:bg-white/5 border border-transparent'
              }`}
            >
              {isActive && <div className="absolute left-0 top-0 w-1 h-full bg-blue-500 shadow-[0_0_10px_#00f3ff]"></div>}
              <Icon size={20} className={isActive ? 'animate-pulse' : ''} />
              <div className="flex flex-col items-start hidden md:flex">
                <span className={`font-cyber text-[10px] tracking-[0.15em] ${isActive ? 'neon-text' : ''}`}>
                  {item.label.toUpperCase()}
                </span>
                <span className="text-[6px] font-mono text-slate-700 group-hover:text-blue-500/50 transition-colors">
                  {isActive ? 'UPLINK_ACTIVE' : 'READY_TO_SYNC'}
                </span>
              </div>
            </button>
          );
        })}
      </nav>

      <div className="mt-auto flex flex-col items-center gap-6 w-full px-4">
        <div className="w-full h-[1px] bg-gradient-to-r from-transparent via-blue-500/20 to-transparent"></div>
        <div className="flex flex-col items-center gap-1">
          <div className="text-[9px] font-cyber text-slate-700 md:block hidden tracking-widest uppercase">Ayush_Kumar_Puhan</div>
          <div className="text-[7px] font-mono text-blue-900 md:block hidden">SECURE_CONNECTION_ENCRYPTED</div>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
