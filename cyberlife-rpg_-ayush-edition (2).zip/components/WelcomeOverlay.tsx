
import React, { useState, useEffect } from 'react';

const WelcomeOverlay: React.FC = () => {
  const [visible, setVisible] = useState(true);
  const [text, setText] = useState('');
  const fullText = 'WELCOME_AYUSH_KUMAR_PUHAN...';
  const [glitch, setGlitch] = useState(false);

  useEffect(() => {
    let i = 0;
    const timer = setInterval(() => {
      setText(fullText.substring(0, i));
      i++;
      if (i > fullText.length) {
        clearInterval(timer);
        setTimeout(() => setVisible(false), 2000);
      }
    }, 100);

    const glitchTimer = setInterval(() => {
      setGlitch(true);
      setTimeout(() => setGlitch(false), 50);
    }, 1500);

    return () => {
      clearInterval(timer);
      clearInterval(glitchTimer);
    };
  }, []);

  if (!visible) return null;

  return (
    <div className="fixed inset-0 z-[100] bg-black flex items-center justify-center overflow-hidden transition-opacity duration-1000">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,rgba(0,243,255,0.1),transparent_70%)]"></div>
      <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,118,0.06))] bg-[length:100%_2px,3px_100%] pointer-events-none opacity-20"></div>
      
      <div className={`relative flex flex-col items-center gap-4 ${glitch ? 'animate-glitch' : ''}`}>
        <div className="w-24 h-24 border-2 border-blue-500 rounded-full flex items-center justify-center animate-spin-slow mb-8">
          <div className="w-16 h-16 border border-blue-400/50 rounded-full animate-pulse"></div>
        </div>
        
        <div className="flex flex-col items-center">
          <div className="text-[10px] font-cyber text-blue-500 tracking-[0.5em] mb-2 uppercase opacity-50">Neural_Link_Established</div>
          <h1 className="text-4xl md:text-6xl font-cyber text-blue-400 neon-text tracking-tighter">
            {text}
            <span className="animate-pulse">_</span>
          </h1>
          <div className="mt-4 flex gap-2">
            {[1, 2, 3, 4, 5].map(i => (
              <div key={i} className="w-8 h-1 bg-blue-500/20 rounded-full overflow-hidden">
                <div className="w-full h-full bg-blue-500 animate-[loading_2s_ease-in-out_infinite]" style={{ animationDelay: `${i * 0.2}s` }}></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes loading {
          0% { transform: translateX(-100%); }
          100% { transform: translateX(100%); }
        }
        .animate-spin-slow {
          animation: spin 8s linear infinite;
        }
      `}</style>
    </div>
  );
};

export default WelcomeOverlay;
