
import React, { useState } from 'react';
import { PenTool, Trash2, Calendar, FileText, Download, Volume2, Loader2 } from 'lucide-react';
import { GoogleGenAI, Modality } from '@google/genai';

interface ArchivesViewProps {
  archives: {id: string, title: string, content: string, date: string}[];
  setArchives: React.Dispatch<React.SetStateAction<{id: string, title: string, content: string, date: string}[]>>;
}

const ArchivesView: React.FC<ArchivesViewProps> = ({ archives, setArchives }) => {
  const [playingId, setPlayingId] = useState<string | null>(null);

  const deleteArchive = (id: string) => {
    setArchives(prev => prev.filter(a => a.id !== id));
  };

  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  const decodeAudioData = async (
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const handleReadAloud = async (id: string, content: string) => {
    if (playingId) return;
    setPlayingId(id);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: content }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: 'Kore' },
            },
          },
        },
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (!base64Audio) throw new Error("Audio generation failed");

      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      const audioBuffer = await decodeAudioData(decode(base64Audio), audioCtx, 24000, 1);
      
      const source = audioCtx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(audioCtx.destination);
      source.onended = () => setPlayingId(null);
      source.start();
    } catch (err) {
      console.error(err);
      setPlayingId(null);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex justify-between items-center border-b border-blue-900/30 pb-4">
        <div className="flex items-center gap-3">
           <PenTool size={24} className="text-purple-400" />
           <h2 className="font-cyber text-xl text-purple-400 neon-text-purple uppercase">Neural_Archives</h2>
        </div>
        <span className="text-[10px] font-cyber text-slate-500">{archives.length} RECORDS_DETECTED</span>
      </div>

      {archives.length === 0 ? (
        <div className="py-32 text-center border border-dashed border-blue-900/20 rounded-[32px] bg-blue-950/5">
           <FileText size={48} className="mx-auto text-slate-800 mb-4" />
           <p className="font-cyber text-[10px] text-slate-600 tracking-widest uppercase">No archived writings found. Ask Velvet to draft something!</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6">
          {archives.map(rec => (
            <div key={rec.id} className="p-8 border border-blue-900/30 bg-black/60 rounded-[32px] hover:border-purple-500/40 transition-all group">
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <div>
                  <h3 className="font-cyber text-lg text-blue-100 group-hover:neon-text-blue transition-all">{rec.title}</h3>
                  <div className="flex items-center gap-3 mt-1 text-[9px] font-cyber text-slate-500">
                    <Calendar size={12} />
                    <span>STORED_AT: {rec.date}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button 
                    onClick={() => handleReadAloud(rec.id, rec.content)}
                    disabled={playingId === rec.id}
                    className="p-2.5 bg-purple-500/10 hover:bg-purple-500 text-purple-400 hover:text-black rounded-xl transition-all border border-purple-500/20 disabled:opacity-50"
                  >
                    {playingId === rec.id ? <Loader2 size={16} className="animate-spin" /> : <Volume2 size={16} />}
                  </button>
                  <button className="p-2.5 bg-blue-500/10 hover:bg-blue-500 text-blue-400 hover:text-black rounded-xl transition-all border border-blue-500/20">
                    <Download size={16} />
                  </button>
                  <button 
                    onClick={() => deleteArchive(rec.id)}
                    className="p-2.5 bg-red-900/20 hover:bg-red-600 text-red-500 hover:text-white rounded-xl transition-all border border-red-900/20"
                  >
                    <Trash2 size={16} />
                  </button>
                </div>
              </div>
              <div className="bg-black/40 border border-blue-900/10 p-6 rounded-2xl">
                <p className="text-xs text-blue-200/80 font-sans leading-relaxed whitespace-pre-wrap">{rec.content}</p>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default ArchivesView;
