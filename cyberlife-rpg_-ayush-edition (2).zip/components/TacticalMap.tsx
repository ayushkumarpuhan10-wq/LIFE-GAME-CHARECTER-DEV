
import React, { useState, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { MapPin, Search, Navigation, ExternalLink, Activity, Globe, Crosshair, Zap } from 'lucide-react';
import { Character } from '../types';

interface TacticalMapProps {
  character: Character;
}

interface WeatherData {
  temp: string;
  condition: string;
  humidity: string;
  windSpeed: string;
  location: string;
}

const TacticalMap: React.FC<TacticalMapProps> = ({ character }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<any[]>([]);
  const [isSearching, setIsSearching] = useState(false);
  const [location, setLocation] = useState<{lat: number, lng: number} | null>(null);
  const [matrixData, setMatrixData] = useState<string[]>([]);
  const [targetingMode, setTargetingMode] = useState(false);

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (pos) => {
          const newLoc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
          setLocation(newLoc);
        },
        (err) => console.error("Geolocation error:", err)
      );
    }

    // Generate random matrix-style data
    const interval = setInterval(() => {
      const data = [
        `UPLINK_STABILITY: ${(Math.random() * 100).toFixed(2)}%`,
        `LATENCY: ${Math.floor(Math.random() * 50)}ms`,
        `PACKET_LOSS: ${(Math.random() * 0.1).toFixed(4)}%`,
        `NEURAL_SYNC: ${(80 + Math.random() * 20).toFixed(2)}%`,
        `ENCRYPTION: AES-256-GCM`,
        `NODE_ID: ${Math.random().toString(36).substring(7).toUpperCase()}`,
        `SIGNAL_STRENGTH: -${Math.floor(Math.random() * 40 + 60)}dBm`
      ];
      setMatrixData(prev => [data[Math.floor(Math.random() * data.length)], ...prev].slice(0, 10));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const handleMapClick = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!targetingMode || !location) return;
    
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    
    const dx = x - centerX;
    const dy = y - centerY;
    
    const latOffset = -(dy * 0.00003);
    const lngOffset = dx * 0.00004;
    
    const newLoc = {
      lat: location.lat + latOffset,
      lng: location.lng + lngOffset
    };
    
    setLocation(newLoc);
    setTargetingMode(false);
    setQuery(`${newLoc.lat.toFixed(4)}, ${newLoc.lng.toFixed(4)}`);
  };

  const handleSearch = async () => {
    if (!query.trim()) return;
    setIsSearching(true);
    try {
      const apiKey = process.env.API_KEY;
      if (!apiKey) throw new Error("API Key Missing");
      const ai = new GoogleGenAI({ apiKey });
      
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: `Find tactical locations for ${character.name} (15yo student) near ${location ? `${location.lat}, ${location.lng}` : 'current location'}: ${query}.`,
        config: {
          tools: [{ googleMaps: {} }],
          toolConfig: {
            retrievalConfig: {
              latLng: location ? { latitude: location.lat, longitude: location.lng } : undefined
            }
          }
        },
      });

      // Extract results
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
      if (chunks) {
        const mapsResults = chunks
          .filter((c: any) => c.maps)
          .map((c: any) => ({
            title: c.maps.title,
            uri: c.maps.uri
          }));
        setResults(mapsResults);
      }

      // Try to update location based on search (simplified)
      // In a real app, we'd use a geocoding API. For now, we'll just search for the place.
      // We'll just use the query as a proxy for location update if it looks like coords
      const coordMatch = query.match(/(-?\d+\.?\d*),\s*(-?\d+\.?\d*)/);
      if (coordMatch) {
        setLocation({ lat: parseFloat(coordMatch[1]), lng: parseFloat(coordMatch[2]) });
      }

    } catch (err: any) {
      console.error("Tactical search error:", err);
      // If the main search fails (likely quota), we still want to show something
      if (err?.message?.includes('429') || err?.message?.includes('RESOURCE_EXHAUSTED')) {
        setResults([{ title: "QUOTA_EXHAUSTED: Using Local Cache", uri: "#" }]);
      }
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto space-y-8 animate-in fade-in duration-500 pb-20">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Left Column: Matrix Data */}
        <div className="lg:col-span-3 space-y-6">
          <div className="cyber-card p-4 rounded-2xl border border-blue-500/20 bg-black/40 backdrop-blur-xl">
            <h3 className="text-[10px] font-cyber text-blue-400 mb-4 flex items-center gap-2">
              <Activity size={12} /> NEURAL_DATA_STREAM
            </h3>
            <div className="space-y-2 font-mono text-[9px] text-blue-300/70">
              {matrixData.map((line, i) => (
                <div key={i} className="flex items-center gap-2 overflow-hidden whitespace-nowrap">
                  <span className="text-blue-500/30">[{i}]</span>
                  <span className="animate-pulse">{line}</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Center Column: Tactical Map */}
        <div className="lg:col-span-6 space-y-8">
          <div className="relative flex justify-center">
            {/* Outer Decorative Rings */}
            <div className="absolute w-[420px] h-[420px] border border-blue-500/10 rounded-full animate-[spin_60s_linear_infinite] pointer-events-none"></div>
            <div className="absolute w-[460px] h-[460px] border border-dashed border-blue-500/5 rounded-full animate-[spin_40s_linear_infinite_reverse] pointer-events-none"></div>
            
            {/* Main Map Container */}
            <div 
              className={`relative w-96 h-96 rounded-full border-4 ${targetingMode ? 'border-red-500 shadow-[0_0_30px_rgba(239,68,68,0.5)]' : 'border-blue-500/30 shadow-[0_0_60px_rgba(0,243,255,0.15)]'} overflow-hidden group glitch-container transition-all duration-300`}
              onClick={handleMapClick}
              style={{ cursor: targetingMode ? 'crosshair' : 'default' }}
            >
              {/* Targeting Overlay */}
              {targetingMode && (
                <div className="absolute inset-0 z-50 bg-red-500/10 flex items-center justify-center pointer-events-auto">
                  <div className="w-full h-[1px] bg-red-500/50 absolute top-1/2"></div>
                  <div className="h-full w-[1px] bg-red-500/50 absolute left-1/2"></div>
                  <div className="text-[10px] font-cyber text-red-500 bg-black/80 px-2 py-1 rounded border border-red-500/50 animate-pulse">
                    SELECT_TARGET_COORDINATES
                  </div>
                </div>
              )}

              {/* Circular Game-Like UI Overlay */}
              <div className="absolute inset-0 pointer-events-none z-10">
                {/* Outer Ring */}
                <div className="absolute inset-0 border-[1px] border-blue-500/20 rounded-full animate-[spin_60s_linear_infinite]"></div>
                {/* Inner Ring with Dashes */}
                <div className="absolute inset-4 border-[2px] border-dashed border-blue-400/10 rounded-full animate-[spin_40s_linear_infinite_reverse]"></div>
                {/* Scanning Line */}
                <div className="absolute top-1/2 left-1/2 w-[45%] h-[1px] bg-gradient-to-r from-transparent via-blue-500/40 to-transparent origin-left animate-[spin_10s_linear_infinite]"></div>
                
                {/* Corner Brackets (Simulated for Circle) */}
                <div className="absolute top-10 left-10 w-8 h-8 border-t-2 border-l-2 border-blue-500/40 rounded-tl-lg"></div>
                <div className="absolute top-10 right-10 w-8 h-8 border-t-2 border-r-2 border-blue-500/40 rounded-tr-lg"></div>
                <div className="absolute bottom-10 left-10 w-8 h-8 border-b-2 border-l-2 border-blue-500/40 rounded-bl-lg"></div>
                <div className="absolute bottom-10 right-10 w-8 h-8 border-b-2 border-r-2 border-blue-500/40 rounded-br-lg"></div>
              </div>
              {/* Real Google Map */}
              <iframe
                title="Tactical Map"
                width="100%"
                height="100%"
                frameBorder="0"
                style={{ 
                  filter: 'invert(90%) hue-rotate(180deg) brightness(0.7) contrast(1.3) saturate(1.5)',
                  pointerEvents: 'auto',
                  transform: 'scale(1.4)'
                }}
                src={`https://www.google.com/maps/embed/v1/view?key=${process.env.GOOGLE_MAPS_API_KEY || ''}&center=${location?.lat || 0},${location?.lng || 0}&zoom=15&maptype=roadmap`}
                srcDoc={!process.env.GOOGLE_MAPS_API_KEY ? `
                  <body style="margin:0; background:#050505; display:flex; align-items:center; justify-content:center; overflow:hidden;">
                    <div style="position:absolute; width:100%; height:100%; background: repeating-linear-gradient(0deg, rgba(0,243,255,0.03) 0px, rgba(0,243,255,0.03) 1px, transparent 1px, transparent 2px); background-size: 100% 2px;"></div>
                    <img src="https://picsum.photos/seed/map/1000/1000?blur=5" style="width:100%; height:100%; object-fit:cover; opacity:0.2; filter: grayscale(1) invert(1) brightness(2);">
                    <div style="position:absolute; color:#00f3ff; font-family:monospace; font-size:12px; letter-spacing:4px; text-align:center; text-shadow: 0 0 10px #00f3ff;">
                      <div style="font-size:10px; opacity:0.5; margin-bottom:10px;">ENCRYPTED_UPLINK</div>
                      ${location ? `${location.lat.toFixed(6)} N<br/>${location.lng.toFixed(6)} E` : 'SCANNING_SECTOR...'}
                    </div>
                  </body>
                ` : undefined}
              ></iframe>

              {/* HUD Overlays */}
              <div className="absolute inset-0 pointer-events-none">
                {/* Scanning Line */}
                <div className="w-full h-[2px] bg-blue-400/50 shadow-[0_0_15px_#00f3ff] absolute top-1/2 -translate-y-1/2 animate-[scan_6s_linear_infinite]"></div>
                
                {/* Radar Sweep */}
                <div className="absolute inset-0 bg-[conic-gradient(from_0deg,rgba(0,243,255,0.15)_0deg,transparent_60deg)] animate-[spin_5s_linear_infinite]"></div>
                
                {/* Vignette & Grid */}
                <div className="absolute inset-0 bg-[radial-gradient(circle,transparent_50%,rgba(0,0,0,0.8)_100%)]"></div>
                <div className="absolute inset-0 border-[30px] border-black/60 rounded-full"></div>
                
                {/* Crosshair */}
                <div className="absolute inset-0 flex items-center justify-center">
                  <div className="w-24 h-[1px] bg-blue-500/20"></div>
                  <div className="h-24 w-[1px] bg-blue-500/20"></div>
                  <div className="w-12 h-12 border border-blue-500/20 rounded-full"></div>
                  <div className="w-32 h-32 border border-blue-500/10 rounded-full"></div>
                  <div className="absolute w-2 h-2 bg-blue-500 rounded-full animate-ping opacity-50"></div>
                </div>

                {/* Compass HUD */}
                <div className="absolute top-6 left-1/2 -translate-x-1/2 text-[10px] font-cyber text-blue-400 font-bold drop-shadow-[0_0_5px_rgba(0,243,255,0.5)]">N</div>
                <div className="absolute bottom-6 left-1/2 -translate-x-1/2 text-[10px] font-cyber text-blue-400 font-bold">S</div>
                <div className="absolute left-6 top-1/2 -translate-y-1/2 text-[10px] font-cyber text-blue-400 font-bold">W</div>
                <div className="absolute right-6 top-1/2 -translate-y-1/2 text-[10px] font-cyber text-blue-400 font-bold">E</div>

                {/* Tech Labels */}
                <div className="absolute top-1/4 left-10 text-[8px] font-mono text-blue-400/50 rotate-90">SEC_LEVEL_4</div>
                <div className="absolute bottom-1/4 right-10 text-[8px] font-mono text-blue-400/50 -rotate-90">UPLINK_STABLE</div>
              </div>
            </div>

            {/* Floating HUD Elements */}
            <div className="absolute -top-4 -right-4 bg-black/80 border border-blue-500/30 p-2 rounded-lg backdrop-blur-md animate-bounce duration-[3000ms] z-30">
              <div className="text-[8px] font-cyber text-blue-400">ALT_MSL</div>
              <div className="text-[12px] font-mono text-white">124.5m</div>
            </div>
            <div className="absolute -bottom-4 -left-4 bg-black/80 border border-emerald-500/30 p-2 rounded-lg backdrop-blur-md flex flex-col items-center gap-1 z-30">
              <div className="text-[8px] font-cyber text-emerald-400">VEL_KTS</div>
              <div className="text-[12px] font-mono text-white">0.0</div>
              <button 
                onClick={() => {
                  if (navigator.geolocation) {
                    navigator.geolocation.getCurrentPosition((pos) => {
                      const newLoc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
                      setLocation(newLoc);
                    });
                  }
                }}
                className="mt-1 p-1 bg-emerald-500/10 border border-emerald-500/20 rounded hover:bg-emerald-500 hover:text-black transition-all text-[8px] font-cyber"
              >
                RE_SYNC
              </button>
            </div>

            {/* Targeting Toggle */}
            <div className="absolute -bottom-4 -right-4 z-30">
              <button 
                onClick={() => setTargetingMode(!targetingMode)}
                className={`p-3 rounded-full border transition-all shadow-lg ${targetingMode ? 'bg-red-500 border-red-400 text-black scale-110' : 'bg-blue-500/20 border-blue-500/50 text-blue-400 hover:bg-blue-500 hover:text-black'}`}
              >
                <Crosshair size={20} className={targetingMode ? 'animate-spin' : ''} />
              </button>
            </div>
          </div>

          {/* Search Bar */}
          <div className="relative group">
            <div className="absolute inset-0 bg-blue-500/5 blur-2xl rounded-3xl group-hover:bg-blue-500/10 transition-all"></div>
            <div className="relative bg-black/60 border border-white/10 p-6 rounded-3xl backdrop-blur-xl">
              <div className="flex gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-500" size={18} />
                  <input 
                    type="text" 
                    value={query}
                    onChange={e => setQuery(e.target.value)}
                    onKeyDown={e => e.key === 'Enter' && handleSearch()}
                    placeholder="ENTER_COORDINATES_OR_LOCATION..."
                    className="w-full bg-black/40 border border-white/10 rounded-2xl py-4 pl-12 pr-4 text-sm font-cyber text-blue-100 focus:neon-border outline-none transition-all"
                  />
                </div>
                <button 
                  onClick={handleSearch}
                  disabled={isSearching}
                  className="bg-blue-500 text-black px-8 rounded-2xl font-cyber text-sm hover:scale-105 active:scale-95 transition-all disabled:opacity-50 flex items-center gap-2 shadow-[0_0_20px_rgba(0,243,255,0.4)]"
                >
                  {isSearching ? <Activity size={18} className="animate-spin" /> : <Navigation size={18} />}
                  {isSearching ? 'SCANNING...' : 'EXECUTE'}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column: Results & Points of Interest */}
        <div className="lg:col-span-3 space-y-4">
          <div className="flex items-center justify-between border-b border-blue-900/30 pb-4">
            <h3 className="text-[10px] font-cyber text-slate-400 uppercase tracking-widest">Points_of_Interest</h3>
            <span className="text-[10px] font-mono text-blue-500">{results.length} NODES</span>
          </div>

          <div className="space-y-3 max-h-[600px] overflow-y-auto pr-2 custom-scrollbar">
            {results.map((res, i) => (
              <div key={i} className="bg-white/5 border border-white/10 p-3 rounded-xl hover:bg-blue-500/10 transition-all group relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-blue-500 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-blue-500/10 rounded-lg flex items-center justify-center border border-blue-500/20">
                      <MapPin size={16} className="text-blue-400" />
                    </div>
                    <div className="min-w-0">
                      <h4 className="text-[11px] font-cyber text-white truncate">{res.title}</h4>
                      <div className="text-[8px] font-mono text-blue-500/50 uppercase">Coordinate_Locked</div>
                    </div>
                  </div>
                  <a href={res.uri} target="_blank" rel="noreferrer" className="p-2 bg-white/5 rounded-lg hover:bg-blue-500 hover:text-black transition-all">
                    <ExternalLink size={14} />
                  </a>
                </div>
              </div>
            ))}
            {results.length === 0 && !isSearching && (
              <div className="py-10 text-center border border-dashed border-white/5 rounded-2xl opacity-30">
                <div className="flex flex-col items-center gap-2">
                  <Crosshair size={24} />
                  <p className="text-[8px] font-cyber uppercase tracking-widest">Awaiting_Target</p>
                </div>
              </div>
            )}
          </div>

          {/* Additional Matrix Stats */}
          <div className="pt-4 border-t border-white/5">
            <div className="bg-blue-500/5 p-4 rounded-2xl border border-blue-500/10">
              <div className="flex items-center gap-2 mb-2">
                <Zap size={12} className="text-blue-400" />
                <span className="text-[10px] font-cyber text-blue-400">SYSTEM_PULSE</span>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-[8px] font-mono">
                  <span className="text-slate-500">CPU_LOAD</span>
                  <span className="text-blue-400">12.4%</span>
                </div>
                <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                  <div className="w-[12%] h-full bg-blue-500"></div>
                </div>
                <div className="flex justify-between text-[8px] font-mono mt-2">
                  <span className="text-slate-500">MEM_USAGE</span>
                  <span className="text-purple-400">4.2GB</span>
                </div>
                <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                  <div className="w-[42%] h-full bg-purple-500"></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TacticalMap;
