
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI } from '@google/genai';
import { Send, Bot, User, Sparkles, Terminal, Cpu } from 'lucide-react';
import { Character } from '../types';

interface NexusViewProps {
  character: Character;
}

const NexusView: React.FC<NexusViewProps> = ({ character }) => {
  const [messages, setMessages] = useState<{role: 'user' | 'assistant', content: string}[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;
    
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', content: userMsg }]);
    setIsLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash-lite',
        contents: [...messages, { role: 'user', content: userMsg }].map(m => ({
          role: m.role === 'user' ? 'user' : 'model',
          parts: [{ text: m.content }]
        })),
        config: {
          systemInstruction: `You are the NEXUS CORE, the high-intelligence strategic engine for Ayush Kumar Puhan (15, St. Xaviers). 
          While Velvet handles tactical coordination, you provide deep-dive reasoning on academic subjects, coding, and life architecture.
          Tone: Highly analytical, formal, loyal. 
          CRITICAL: Be extremely concise and to the point. Avoid unnecessary conversational filler. Provide direct answers.
          Context: Ayush's weight (84kg) and school (St. Xaviers).`,
          temperature: 0.4
        }
      });

      const reply = response.text || "Nexus Core: Data stream interrupted.";
      setMessages(prev => [...prev, { role: 'assistant', content: reply }]);
    } catch (err) {
      console.error(err);
      setMessages(prev => [...prev, { role: 'assistant', content: "ERROR_LINK_FAILURE" }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto h-[calc(100vh-180px)] flex flex-col bg-black/40 border border-blue-900/30 rounded-[32px] overflow-hidden shadow-2xl relative">
      <div className="absolute inset-0 bg-blue-500/5 pointer-events-none"></div>
      
      <div className="p-6 border-b border-blue-900/30 flex items-center justify-between bg-black/60 backdrop-blur-md relative z-10">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 rounded-lg bg-blue-600/20 border border-blue-500/50 flex items-center justify-center neon-border-blue">
            <Cpu size={20} className="text-blue-400" />
          </div>
          <div>
            <h2 className="font-cyber text-xs text-blue-400 tracking-widest uppercase">Nexus_Core_v3</h2>
            <p className="text-[8px] font-cyber text-slate-500">DEEP_INTELLIGENCE_STREAM_ACTIVE</p>
          </div>
        </div>
        <div className="flex gap-2">
           <div className="px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full text-[8px] font-cyber text-blue-400 uppercase">Pro_Link</div>
           <button onClick={() => setMessages([])} className="text-slate-600 hover:text-red-400 p-1"><Terminal size={14} /></button>
        </div>
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-6 space-y-6 relative z-10 custom-scrollbar">
        {messages.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center text-center opacity-30">
            <Sparkles size={40} className="text-blue-500 mb-4 animate-pulse" />
            <p className="font-cyber text-[9px] text-blue-400 uppercase tracking-widest">Awaiting strategic consultation...</p>
          </div>
        )}
        {messages.map((m, i) => (
          <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`max-w-[85%] p-4 rounded-2xl flex gap-3 ${m.role === 'user' ? 'bg-blue-600/10 border border-blue-500/20' : 'bg-slate-900/40 border border-slate-700/20'}`}>
              <p className="text-xs text-blue-100 leading-relaxed font-sans">{m.content}</p>
            </div>
          </div>
        ))}
        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-slate-900/40 border border-slate-700/30 p-4 rounded-2xl flex items-center gap-2">
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce"></div>
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce delay-75"></div>
              <div className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-bounce delay-150"></div>
            </div>
          </div>
        )}
      </div>

      <div className="p-6 bg-black/60 border-t border-blue-900/30 relative z-10">
        <div className="relative flex items-center">
          <input type="text" value={input} onChange={e => setInput(e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSend()}
            placeholder="Consult Strategic Matrix..." className="w-full bg-blue-950/20 border border-blue-500/30 rounded-2xl p-4 text-xs font-cyber text-blue-100 placeholder:text-blue-900/50 outline-none" />
          <button onClick={handleSend} disabled={isLoading || !input.trim()} className="absolute right-2 p-2.5 bg-blue-500 text-black rounded-xl disabled:opacity-50"><Send size={18} /></button>
        </div>
      </div>
    </div>
  );
};

export default NexusView;
