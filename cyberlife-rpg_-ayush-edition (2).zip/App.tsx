
import React, { useState, useEffect, useRef } from 'react';
import { Task, TaskCategory, Character, Hobby, RPGStats, GlobalToolsState, SkillType, SkillRank, SkillProgression, ReflectionLog, FocusQuality } from './types';
import Sidebar from './components/Sidebar';
import HUD from './components/HUD';
import { Zap } from 'lucide-react';
import TaskManager from './components/TaskManager';
import StatsView from './components/StatsView';
import HobbyManager from './components/HobbyManager';
import SpecialSection from './components/SpecialSection';
import VelvetAI from './components/VelvetAI';
import CalendarView from './components/CalendarView';
import ProfileView from './components/ProfileView';
import NexusView from './components/NexusView';
import ArchivesView from './components/ArchivesView';
import SkillMatrix from './components/SkillMatrix';
import ReflectionLogView from './components/ReflectionLog';
import SkillArena from './components/SkillArena';
import TacticalMap from './components/TacticalMap';
import WelcomeOverlay from './components/WelcomeOverlay';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'tasks' | 'stats' | 'hobbies' | 'calendar' | 'tools' | 'profile' | 'nexus' | 'archives' | 'skills' | 'reflections' | 'arena' | 'recon'>('profile');
  const [tasks, setTasks] = useState<Task[]>([]);
  const [hobbies, setHobbies] = useState<Hobby[]>([]);
  const [archives, setArchives] = useState<{id: string, title: string, content: string, date: string}[]>([]);
  
  // Shared Tools State
  const [toolsState, setToolsState] = useState<GlobalToolsState>({
    stopwatch: { time: 0, running: false },
    timer: { seconds: 0, running: false }
  });

  const swIntervalRef = useRef<number | null>(null);
  const timerIntervalRef = useRef<number | null>(null);

  const [character, setCharacter] = useState<Character>({
    name: 'AYUSH KUMAR PUHAN',
    alias: 'NET_RUNNER_01',
    bio: 'Decentralized entity navigating the physical-digital divide.',
    level: 1,
    totalXP: 0,
    avatarUrl: 'https://picsum.photos/seed/ayush-cyber-full/512/768',
    profilePicUrl: 'https://picsum.photos/seed/ayush-cyber-head/200/200',
    themeColor: '#00f3ff',
    textColor: '#ffffff',
    backgroundColor: '#000000',
    wardrobe: [],
    equipped: {
      torso: undefined,
      mobile: undefined,
      laptop: undefined,
      bag: undefined
    },
    appearance: {
      skinTone: '#d2b48c',
      hairStyle: 'Cyber-Undercut',
      hairColor: '#00f3ff',
      eyeColor: '#bc13fe',
      pose: 'Dynamic',
      bodyType: 'Athletic',
      facialFeatures: ['Neon-Tattoo', 'Cyber-Eye'],
      background: 'Holographic-Pedestal'
    },
    personalDetails: {
      age: 15,
      height: "5.8",
      weight: 84,
      school: "St. Xaviers School",
      birthday: "2010-04-01"
    },
    stats: {
      mentalHealth: 10,
      discipline: 10,
      health: 10,
      work: 10,
      study: 10,
      hobbies: 10,
    },
    learningEfficiency: 1.0,
    reflections: [],
    skills: {
      [SkillType.COGNITIVE]: { type: SkillType.COGNITIVE, xp: 0, rank: SkillRank.NOVICE, lastActivity: new Date().toISOString(), subSkills: ['Logic', 'Memory', 'Focus'] },
      [SkillType.PHYSICAL]: { type: SkillType.PHYSICAL, xp: 0, rank: SkillRank.NOVICE, lastActivity: new Date().toISOString(), subSkills: ['Strength', 'Stamina', 'Agility'] },
      [SkillType.COMMUNICATION]: { type: SkillType.COMMUNICATION, xp: 0, rank: SkillRank.NOVICE, lastActivity: new Date().toISOString(), subSkills: ['Writing', 'Speaking', 'Empathy'] },
      [SkillType.TECHNICAL]: { type: SkillType.TECHNICAL, xp: 0, rank: SkillRank.NOVICE, lastActivity: new Date().toISOString(), subSkills: ['Coding', 'Hardware', 'Systems'] },
      [SkillType.EMOTIONAL]: { type: SkillType.EMOTIONAL, xp: 0, rank: SkillRank.NOVICE, lastActivity: new Date().toISOString(), subSkills: ['Discipline', 'Resilience', 'Self-Control'] }
    }
  });

  useEffect(() => {
    const hex = character.themeColor.replace('#', '');
    const r = parseInt(hex.length === 3 ? hex[0] + hex[0] : hex.substring(0, 2), 16);
    const g = parseInt(hex.length === 3 ? hex[1] + hex[1] : hex.substring(2, 4), 16);
    const b = parseInt(hex.length === 3 ? hex[2] + hex[2] : hex.substring(4, 6), 16);
    
    document.documentElement.style.setProperty('--glow', character.themeColor);
    document.documentElement.style.setProperty('--glow-rgb', `${r}, ${g}, ${b}`);
    document.documentElement.style.setProperty('--text-color', character.textColor);
    document.documentElement.style.setProperty('--bg-color', character.backgroundColor);
    
    document.body.style.backgroundColor = character.backgroundColor;
    document.body.style.color = character.textColor;
  }, [character.themeColor, character.textColor, character.backgroundColor]);

  useEffect(() => {
    const decayInterval = setInterval(() => {
      setCharacter(prev => {
        const newSkills = { ...prev.skills };
        let changed = false;
        const now = new Date().getTime();
        const decayThreshold = 14 * 24 * 60 * 60 * 1000; // 14 days

        (Object.values(newSkills) as SkillProgression[]).forEach(skill => {
          const last = new Date(skill.lastActivity).getTime();
          if (now - last > decayThreshold && skill.xp > 0) {
            skill.xp = Math.max(0, skill.xp - 50); // Decay 50 XP per check
            changed = true;
          }
        });

        return changed ? { ...prev, skills: newSkills } : prev;
      });
    }, 1000 * 60 * 60 * 24); // Check once a day

    return () => clearInterval(decayInterval);
  }, []);

  useEffect(() => {
    const savedTasks = localStorage.getItem('cyber-tasks');
    const savedCharacter = localStorage.getItem('cyber-char');
    const savedHobbies = localStorage.getItem('cyber-hobbies');
    const savedArchives = localStorage.getItem('cyber-archives');
    
    if (savedTasks) setTasks(JSON.parse(savedTasks));
    if (savedCharacter) setCharacter(JSON.parse(savedCharacter));
    if (savedHobbies) setHobbies(JSON.parse(savedHobbies));
    if (savedArchives) setArchives(JSON.parse(savedArchives));
  }, []);

  useEffect(() => {
    localStorage.setItem('cyber-tasks', JSON.stringify(tasks));
    localStorage.setItem('cyber-char', JSON.stringify(character));
    localStorage.setItem('cyber-hobbies', JSON.stringify(hobbies));
    localStorage.setItem('cyber-archives', JSON.stringify(archives));
  }, [tasks, character, hobbies, archives]);

  // Stopwatch Logic
  useEffect(() => {
    if (toolsState.stopwatch.running) {
      swIntervalRef.current = window.setInterval(() => {
        setToolsState(prev => ({
          ...prev,
          stopwatch: { ...prev.stopwatch, time: prev.stopwatch.time + 10 }
        }));
      }, 10);
    } else {
      if (swIntervalRef.current) clearInterval(swIntervalRef.current);
    }
    return () => { if (swIntervalRef.current) clearInterval(swIntervalRef.current); };
  }, [toolsState.stopwatch.running]);

  // Timer Logic
  useEffect(() => {
    if (toolsState.timer.running && toolsState.timer.seconds > 0) {
      timerIntervalRef.current = window.setInterval(() => {
        setToolsState(prev => {
          const nextSec = prev.timer.seconds - 1;
          if (nextSec <= 0) {
            if (timerIntervalRef.current) clearInterval(timerIntervalRef.current);
            return { ...prev, timer: { ...prev.timer, seconds: 0, running: false } };
          }
          return { ...prev, timer: { ...prev.timer, seconds: nextSec } };
        });
      }, 1000);
    } else if (toolsState.timer.seconds === 0 && toolsState.timer.running) {
      setToolsState(prev => ({ ...prev, timer: { ...prev.timer, running: false } }));
    }
    return () => { if (timerIntervalRef.current) clearInterval(timerIntervalRef.current); };
  }, [toolsState.timer.running, toolsState.timer.seconds]);

  const addTask = (task: Omit<Task, 'id' | 'completed' | 'xp'>) => {
    const xpValues = {
      [TaskCategory.HEALTH]: 50,
      [TaskCategory.WORK]: 40,
      [TaskCategory.STUDY]: 40,
      [TaskCategory.MENTAL_HEALTH]: 30,
      [TaskCategory.DISCIPLINE]: 35,
      [TaskCategory.HOBBIES]: 25,
    };
    const newTask: Task = {
      ...task,
      id: Math.random().toString(36).substr(2, 9),
      completed: false,
      xp: xpValues[task.category] || 20
    };
    setTasks([...tasks, newTask]);
    return newTask;
  };

  const completeTask = (id: string, focusQuality: FocusQuality = 'standard') => {
    setTasks(prev => prev.map(t => {
      if (t.id === id && !t.completed) {
        handleLevelUp(t.xp, t.category, focusQuality);
        return { ...t, completed: true, focusQuality };
      }
      return t;
    }));
  };

  const deleteTask = (id: string) => {
    setTasks(prev => prev.filter(t => t.id !== id));
  };

  const addReflection = (content: string, analysis: string) => {
    const newLog: ReflectionLog = {
      id: Math.random().toString(36).substr(2, 9),
      date: new Date().toISOString(),
      content,
      analysis
    };
    setCharacter(prev => ({
      ...prev,
      reflections: [newLog, ...prev.reflections],
      learningEfficiency: Math.min(2.0, prev.learningEfficiency + 0.05) // Boost efficiency by 5% per reflection
    }));
  };

  const handleSkillTest = (skillType: SkillType, success: boolean) => {
    if (success) {
      setCharacter(prev => {
        const newSkills = { ...prev.skills };
        newSkills[skillType].xp += 2000; // Large XP reward
        newSkills[skillType].lastActivity = new Date().toISOString();
        return { ...prev, skills: newSkills, totalXP: prev.totalXP + 1000 };
      });
      alert(`ARENA_SYNC_SUCCESS: Neural domain ${skillType} optimized. +2000 Skill XP.`);
    } else {
      alert(`ARENA_SYNC_FAILURE: Neural domain ${skillType} unstable. No XP gained.`);
    }
    setActiveTab('skills');
  };

  const handleLevelUp = (xp: number, category: TaskCategory, focusQuality: FocusQuality = 'standard') => {
    setCharacter(prev => {
      // Practice Quality Multiplier
      let multiplier = 1.0;
      if (focusQuality === 'deep') multiplier = 2.0;
      if (focusQuality === 'distracted') multiplier = 0.5;
      
      const finalXP = Math.floor(xp * multiplier * prev.learningEfficiency);
      const newTotalXP = prev.totalXP + finalXP;
      const newLevel = Math.floor(newTotalXP / 1000) + 1;
      
      const categoryMap: Record<TaskCategory, keyof RPGStats> = {
        [TaskCategory.MENTAL_HEALTH]: 'mentalHealth',
        [TaskCategory.DISCIPLINE]: 'discipline',
        [TaskCategory.HEALTH]: 'health',
        [TaskCategory.WORK]: 'work',
        [TaskCategory.STUDY]: 'study',
        [TaskCategory.HOBBIES]: 'hobbies'
      };
      
      const skillMap: Record<TaskCategory, SkillType[]> = {
        [TaskCategory.MENTAL_HEALTH]: [SkillType.EMOTIONAL],
        [TaskCategory.DISCIPLINE]: [SkillType.EMOTIONAL],
        [TaskCategory.HEALTH]: [SkillType.PHYSICAL],
        [TaskCategory.WORK]: [SkillType.TECHNICAL, SkillType.COMMUNICATION],
        [TaskCategory.STUDY]: [SkillType.COGNITIVE, SkillType.TECHNICAL],
        [TaskCategory.HOBBIES]: [SkillType.COMMUNICATION]
      };

      const statKey = categoryMap[category];
      const newStats = { ...prev.stats };
      if (statKey) newStats[statKey] += Math.floor(finalXP / 10);

      // Skill Progression
      const newSkills = { ...prev.skills };
      const relatedSkills = skillMap[category] || [];
      
      relatedSkills.forEach(skillType => {
        const skill = newSkills[skillType];
        const skillXP = Math.floor(finalXP * 0.5); // Skill XP is half of base XP
        skill.xp += skillXP;
        skill.lastActivity = new Date().toISOString();
        
        // Rank Progression
        const thresholds = [0, 1000, 3000, 7000, 15000, 30000];
        const ranks = [SkillRank.NOVICE, SkillRank.APPRENTICE, SkillRank.SKILLED, SkillRank.ADVANCED, SkillRank.ELITE, SkillRank.MASTER];
        
        let newRank = ranks[0];
        for (let i = thresholds.length - 1; i >= 0; i--) {
          if (skill.xp >= thresholds[i]) {
            newRank = ranks[i];
            break;
          }
        }
        skill.rank = newRank;
      });

      return { ...prev, level: newLevel, totalXP: newTotalXP, stats: newStats, skills: newSkills };
    });
  };

  const addArchive = (title: string, content: string) => {
    setArchives(prev => [{
      id: Math.random().toString(36).substr(2, 9),
      title,
      content,
      date: new Date().toLocaleString()
    }, ...prev]);
  };

  return (
    <div 
      className="flex h-screen overflow-hidden relative selection:bg-blue-500/30 selection:text-blue-200 transition-colors duration-700"
      style={{ 
        backgroundColor: character.backgroundColor,
        color: character.textColor,
        '--theme-color': character.themeColor,
        '--text-color': character.textColor,
        '--bg-color': character.backgroundColor
      } as React.CSSProperties}
    >
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_50%,var(--theme-color,rgba(0,243,255,1)),transparent_70%)] opacity-[0.03] pointer-events-none"></div>
      <div className="absolute inset-0 bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,118,0.06))] bg-[length:100%_2px,3px_100%] pointer-events-none opacity-20"></div>
      <div className="scanning-bar"></div>
      <div className="scanlines"></div>
      
      {/* Dynamic Glitch Overlay */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.02] mix-blend-overlay bg-[url('https://grainy-gradients.vercel.app/noise.svg')]"></div>
      <WelcomeOverlay />
      <Sidebar activeTab={activeTab} setActiveTab={setActiveTab} />
      <main className="flex-1 flex flex-col min-w-0 relative">
        <HUD character={character} />
        <div className="flex-1 overflow-y-auto p-8 custom-scrollbar relative">
          {/* Background Decorative Elements */}
          <div className="absolute top-0 right-0 w-64 h-64 bg-blue-500/5 blur-[100px] pointer-events-none"></div>
          <div className="absolute bottom-0 left-0 w-96 h-96 bg-purple-500/5 blur-[120px] pointer-events-none"></div>
          
          <div className="relative z-10 space-y-8">
            {activeTab === 'profile' && (
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
                <div className="lg:col-span-2">
                  <ProfileView character={character} setCharacter={setCharacter} />
                </div>
                <div className="space-y-8">
                  <div className="cyber-card p-6 rounded-3xl border border-blue-500/20 bg-black/60 backdrop-blur-xl">
                    <h3 className="text-[10px] font-cyber text-blue-400 mb-4 flex items-center gap-2">
                      <Zap size={12} /> SYSTEM_STATUS
                    </h3>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-mono text-slate-400">NEURAL_LOAD</span>
                        <span className="text-[10px] font-mono text-blue-400">24%</span>
                      </div>
                      <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                        <div className="w-[24%] h-full bg-blue-500"></div>
                      </div>
                      <div className="flex justify-between items-center">
                        <span className="text-[10px] font-mono text-slate-400">UPTIME</span>
                        <span className="text-[10px] font-mono text-emerald-400">142:12:04</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}
            
            {activeTab === 'tasks' && <TaskManager tasks={tasks} onAddTask={addTask} onCompleteTask={completeTask} onDeleteTask={deleteTask} />}
            {activeTab === 'stats' && <StatsView stats={character.stats} />}
            {activeTab === 'hobbies' && <HobbyManager hobbies={hobbies} setHobbies={setHobbies} onXPGain={(xp) => handleLevelUp(xp, TaskCategory.HOBBIES)} />}
            {activeTab === 'calendar' && <CalendarView tasks={tasks} />}
            {activeTab === 'tools' && <SpecialSection toolsState={toolsState} setToolsState={setToolsState} />}
            {activeTab === 'skills' && <SkillMatrix character={character} />}
            {activeTab === 'reflections' && <ReflectionLogView character={character} onAddReflection={addReflection} />}
            {activeTab === 'arena' && <SkillArena character={character} onCompleteTest={handleSkillTest} />}
            {activeTab === 'recon' && <TacticalMap character={character} />}
            {activeTab === 'nexus' && <NexusView character={character} />}
            {activeTab === 'archives' && <ArchivesView archives={archives} setArchives={setArchives} />}
          </div>
        </div>
      </main>
      <VelvetAI 
        character={character} 
        tasks={tasks} 
        onAddTask={addTask} 
        onCompleteTask={completeTask}
        toolsState={toolsState}
        setToolsState={setToolsState}
        addArchive={addArchive}
      />
    </div>
  );
};

export default App;
